# plugin.video.invidious
Invidious Addon for Kodi.

Download the latest version from [here](https://github.com/lekma/plugin.video.invidious/releases/).
[script.module.iapc](https://github.com/lekma/script.module.iapc/) is available [here](https://github.com/lekma/script.module.iapc/releases/).

[Invidious instances](https://instances.invidio.us/?sort_by=health)
