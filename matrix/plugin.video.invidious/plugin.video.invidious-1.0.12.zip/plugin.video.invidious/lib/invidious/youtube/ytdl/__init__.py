# -*- coding: utf-8 -*-


# lifted from: https://github.com/ytdl-org/youtube-dl/tree/master/youtube_dl
# LICENSE: The Unlicense, https://github.com/ytdl-org/youtube-dl/blob/master/LICENSE
# AUTHORS: https://github.com/ytdl-org/youtube-dl/blob/master/AUTHORS


from .jsinterp import JSInterpreter

del jsinterp
