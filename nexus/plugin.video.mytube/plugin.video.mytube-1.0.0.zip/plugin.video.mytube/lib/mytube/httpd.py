# -*- coding: utf-8 -*-


from functools import wraps
from itertools import chain
from json import dumps
from time import time

from iapc import Server, http
from iapc.tools import notify, ICONERROR

from .adaptive import adaptive
from .extract import (
    getData, MyChannel, MyContents, MyGenerated,
    MyPlaylist, MyResults, MyRss, MyTrending, MyVideo
)
from .search import queryTypes, sortBy
from .session import MySession
from .solver import MySolver


# cached -----------------------------------------------------------------------

def cached(name):
    def decorator(func):
        @wraps(func)
        def wrapper(self, key, *args, **kwargs):
            cache = self.__cache__.setdefault(name, {})
            if (
                (not (value := cache.get(key))) or
                (
                    (expires := getattr(value, "__expires__", None)) and
                    (time() >= expires)
                )
            ):
                value = cache[key] = func(self, *(args or (key,)), **kwargs)
            return value
        return wrapper
    return decorator


# continuation decorators ------------------------------------------------------

def continue_search(func):
    def wrapper(self, type, *args, **kwargs):
        if (continuation := kwargs.pop("continuation", None)):
            return MyResults(self.__continue_search__(continuation), type)
        return func(self, type, *args, **kwargs)
    return wrapper


def continue_browse(func):
    def wrapper(self, *args, **kwargs):
        if (continuation := kwargs.pop("continuation", None)):
            return MyContents(self.__continue_browse__(continuation))
        return func(self, *args, **kwargs)
    return wrapper


# ------------------------------------------------------------------------------
# MyServer

class MyServer(Server):

    def __init__(self, *args, **kwargs):
        super(MyServer, self).__init__(*args, **kwargs)
        self.playUrl = "http://{}:{}/play".format(*self.server_address)
        self.__session__ = MySession(self.logger, "httpd.session")
        self.__cache__ = {}
        self.__info_methods__ = {
            "channel": self.__channel__,
            "playlist": self.__cached_playlist__,
            "video": self.__watch__
        }

    def __setup__(self):
        self.__session__.__setup__()
        self.__cache__.clear()

    def __raise__(self, error, throw=True):
        if not isinstance(error, Exception):
            error = Exception(error)
        notify(f"error: {error}", icon=ICONERROR)
        if throw:
            raise error

    def server_close(self):
        self.__cache__.clear()
        self.__session__.close()
        super(MyServer, self).server_close()

    # cached -------------------------------------------------------------------

    @cached("videos")
    def __watch__(self, id):
        return MyVideo(self.playUrl, *self.__session__.watch(v=id))

    @cached("solvers")
    def __solver__(self, jsUrl):
        return MySolver(self.__session__.js(jsUrl))

    @cached("channels")
    def __channel__(self, id):
        return MyChannel(self.__session__.browse(browseId=id))

    @cached("playlists")
    def __cached_playlist__(self, id):
        return MyPlaylist(self.__session__.browse(browseId=f"VL{id}"))

    @cached("trending")
    def __cached_trending__(self, params):
        return MyTrending(
            self.__session__.browse(browseId="FEtrending", params=params)
        )

    @cached("generated")
    def __generated__(self, id):
        return MyGenerated(self.__session__.browse(browseId=id))

    # infos --------------------------------------------------------------------

    def __infos__(self, key, id):
        return self.__info_methods__[key](id)[key]

    # continue -----------------------------------------------------------------

    def __continue__(self, url, continuation, responseKey):
        return getData(
            self.__session__.__continue__(url, continuation),
            (responseKey, []),
            (0, {}),
            ("appendContinuationItemsAction", {}),
            ("continuationItems", [])
        )

    def __continue_browse__(self, continuation):
        return self.__continue__(
            "/browse", continuation, "onResponseReceivedActions"
        )

    def __continue_search__(self, continuation):
        return self.__continue__(
            "/search", continuation, "onResponseReceivedCommands"
        )

    # channel ------------------------------------------------------------------

    def __tab__(self, id, key, **kwargs):
        if (channel := self.__channel__(id)):
            data = None
            if (continuation := kwargs.pop("continuation", None)):
                data = self.__continue_browse__(continuation)
            elif (params := channel.get("tabs", {}).get(key, {}).get("params")):
                data = channel.tabData(key, self.__session__.browse(**params))
            if data:
                return (channel["channel"], channel.tabContents(data))

    def __playlists__(self, id, **kwargs):
        if (channel := self.__channel__(id)):
            data = None
            if (continuation := kwargs.pop("continuation", None)):
                data = self.__continue_browse__(continuation)
            else:
                data = channel.tabData(
                    "playlists",
                    self.__session__.playlists(id, view=1, sort="lad")
                )
            if data:
                return (channel["channel"], channel.tabContents(data))

    # --------------------------------------------------------------------------

    def __video__(self, id, key="video"):
        return self.__watch__(id)[key]

    def __playlist__(self, id, **kwargs):
        if (playlist := self.__cached_playlist__(id)):
            if (continuation := kwargs.pop("continuation", None)):
                videos = MyContents(self.__continue_browse__(continuation))
            else:
                videos = playlist["videos"]
            return (playlist["playlist"], videos)

    # feed ---------------------------------------------------------------------

    def __feed__(self, id):
        return MyRss(self.__session__.rss(channel_id=id))

    def __feeds__(self, *ids):
        return chain.from_iterable(self.__feed__(id) for id in ids)

    # trending -----------------------------------------------------------------

    def __trending__(self, params="", **kwargs):
        if (channel := self.__cached_trending__(params)):
            return (channel["channel"], channel["videos"], channel["folders"])

    # autogenerated ------------------------------------------------------------

    def __autogenerated__(self, id, **kwargs):
        if (channel := self.__generated__(id)):
            #return (channel["channel"], channel["contents"])
            return (
                channel["channel"],
                {
                    "continuation": None,
                    "contents": [
                        self.__cached_playlist__(id)["playlist"]
                        for id in channel["contents"]
                    ]
                }
            )

    # search -------------------------------------------------------------------

    __searchParams__ = {
        qtk: {
            sbk: f"CA{sbv['param']}SAhA{qtv['param']}"
            for sbk, sbv in sortBy.items()
        }
        for qtk, qtv in queryTypes.items()
    }

    def __start_search__(self, type, query, sort_by="relevance"):
        return getData(
            self.__session__.search(
                params=self.__searchParams__[type][sort_by],
                query=query
            ),
            ("contents", {}),
            ("twoColumnSearchResultsRenderer", {}),
            ("primaryContents", {}),
            ("sectionListRenderer", {}),
            ("contents", [])
        )

    def __search__(self, type, **kwargs):
        data = None
        if (continuation := kwargs.pop("continuation", None)):
            data = self.__continue_search__(continuation)
        else:
            if (not (query := kwargs.pop("query"))):
                self.__raise__("Missing search query")
            data = self.__start_search__(type, query, **kwargs)
        if data:
            return MyResults(data, type)

    # --------------------------------------------------------------------------

    def __json__(self, response, headers=None):
        return (200, (dumps(response), "application/json"), headers)

    # channel related methods --------------------------------------------------

    def tab(self, key, **kwargs):
        if (id := kwargs.pop("id")):
            return self.__json__(self.__tab__(id, key, **kwargs))
        self.__raise__("Missing channel id")

    @http()
    def videos(self, **kwargs):
        return self.tab("videos", **kwargs)

    @http()
    def shorts(self, **kwargs):
        return self.tab("shorts", **kwargs)

    @http()
    def streams(self, **kwargs):
        return self.tab("streams", **kwargs)

    @http()
    def playlists(self, **kwargs):
        if (id := kwargs.pop("id")):
            return self.__json__(self.__playlists__(id, **kwargs))
        self.__raise__("Missing channel id")

    @http()
    def feed(self, **kwargs):
        if (id := kwargs.pop("id")):
            return self.__json__(self.__feed__(id))
        self.__raise__("Missing channel id")

    # --------------------------------------------------------------------------

    @http()
    def video(self, **kwargs):
        if (id := kwargs.pop("id")):
            return self.__json__(self.__video__(id))
        self.__raise__("Missing video id")

    @http()
    def channel(self, **kwargs):
        if (id := kwargs.pop("id")):
            return self.__json__(self.__channel__(id)["channel"])
        self.__raise__("Missing channel id")

    @http()
    def playlist(self, **kwargs):
        if (id := kwargs.pop("id")):
            return self.__json__(self.__playlist__(id, **kwargs))
        self.__raise__("Missing playlist id")

    # search -------------------------------------------------------------------

    @http()
    def search(self, **kwargs):
        if (type := kwargs.pop("type")):
            return self.__json__(self.__search__(type, **kwargs))
        self.__raise__("Missing search type")

    # play ---------------------------------------------------------------------

    @http()
    def play(self, **kwargs):
        if (id := kwargs.pop("id")):
            video = self.__video__(id, key="play")
            status = video["status"]
            if status["status"].lower() == "ok":
                if video["isLive"]:
                    if (hlsUrl := video.get("hlsManifestUrl")):
                        return (302, None, {"Location": hlsUrl})
                else:
                    if (
                        (not (manifest := video.get("dashManifest"))) and
                        (streams := video.get("adaptiveFormats"))
                    ):
                        solver = self.__solver__(video["jsUrl"])
                        for stream in streams:
                            stream["url"] = solver.extractUrl(stream)
                        manifest = adaptive(video["lengthSeconds"], streams)
                        video["dashManifest"] = manifest
                    if manifest:
                        return (200, manifest, None)
            reason = status.get("reason", "Unknown error")
            self.__raise__(f"Unable to play video: '{id}' [reason: {reason}]")
        self.__raise__("Missing video id")

    # trending -----------------------------------------------------------------

    @http()
    def trending(self, **kwargs):
        return self.__json__(self.__trending__(**kwargs))

    # autogenerated ------------------------------------------------------------

    @http()
    def autogenerated(self, **kwargs):
        if (id := kwargs.pop("id")):
            return self.__json__(self.__autogenerated__(id, **kwargs))
        self.__raise__("Missing channel id")

    # test ---------------------------------------------------------------------

    @http()
    def test(self, **kwargs):
        return self.__json__(self.__session__.browse(**kwargs))
