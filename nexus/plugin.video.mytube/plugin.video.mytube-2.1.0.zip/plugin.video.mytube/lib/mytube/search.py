# -*- coding: utf-8 -*-


from collections import OrderedDict

from iapc import Client
from iapc.tools import (
    containerRefresh, containerUpdate, getAddonId, inputDialog,
    localizedString, notify, selectDialog
)

from .items import Queries


# search parameters ------------------------------------------------------------

queryTypes = OrderedDict(
    (
        ("videos", {"label": 30003, "param": "B"}),
        ("channels", {"label": 30004, "param": "C"}),
        ("playlists", {"label": 30005, "param": "D"})
    )
)

sortBy = OrderedDict(
    (
        ("relevance", {"label": 30131, "param": "A"}),
        ("upload_date", {"label": 30132, "param": "I"}),
        ("view_count", {"label": 30133, "param": "M"}),
        ("rating", {"label": 30134, "param": "E"})
    )
)


#-------------------------------------------------------------------------------

client = Client()


def __sortBy__(sort_by="relevance"):
    keys = list(sortBy.keys())
    index = selectDialog(
        [localizedString(value["label"]) for value in sortBy.values()],
        heading=30130, preselect=keys.index(sort_by)
    )
    if index >= 0:
        sort_by = keys[index]
    return sort_by


def newSearch(type, sort_by=None, history=False):
    if (query := inputDialog(heading=30002)):
        if sort_by is None:
            sort_by = __sortBy__()
        if history:
            client.history.record(type, query, sort_by)
    return (query, sort_by)


def searchHistory(type):
    return Queries(
        reversed(client.history.values(type)),
        category=queryTypes[type]["label"]
    )


# scripts ----------------------------------------------------------------------

__search_url__ = f"plugin://{getAddonId()}/?action=search"

def clearSearchHistory(type=None, update=False):
    client.history.clear(type=type)
    if type:
        containerRefresh()
    else:
        notify(30114, time=2000)
        if update:
            containerUpdate(__search_url__, "replace")
        else:
            containerRefresh()


def removeSearchQuery(type, query):
    client.history.remove(type, query)
    containerRefresh()


def updateSortBy(type, query, _sort_by_):
    if ((sort_by := __sortBy__(sort_by=_sort_by_)) != _sort_by_):
        client.history.record(type, query, sort_by)
        containerRefresh()

