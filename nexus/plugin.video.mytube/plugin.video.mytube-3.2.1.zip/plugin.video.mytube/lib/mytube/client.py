# -*- coding: utf-8 -*-


from iapc import Client

from mytube.items import (
    FeedChannels, Folders, Playlists, Queries, Results, Video, Videos
)


# ------------------------------------------------------------------------------
# MyClient

class MyClient(object):

    def __init__(self, logger):
        self.logger = logger.getLogger(f"{logger.component}.client")
        self.__client__ = Client()

    # video --------------------------------------------------------------------

    def video(self, **kwargs):
        if (video := self.__client__.video(**kwargs)):
            return (Video(video).makeItem(video["url"]), video["manifestType"])
        return (None, None)

    # channel ------------------------------------------------------------------

    def tabs(self, *args, **kwargs):
        #self.logger.info(f"tabs(args={args}, kwargs={kwargs})")
        if (tabs := self.__client__.browse.tabs(*args, **kwargs)):
            return Folders(tabs, **kwargs)

    def __tab__(self, key, **kwargs):
        category, videos = self.__client__.browse.tab(key, **kwargs)
        return Videos(videos, category=category)

    def videos(self, **kwargs):
        return self.__tab__("videos", **kwargs)

    def shorts(self, **kwargs):
        return self.__tab__("shorts", **kwargs)

    def streams(self, **kwargs):
        return self.__tab__("streams", **kwargs)

    def playlists(self, **kwargs):
        category, playlists = self.__client__.browse.playlists(**kwargs)
        return Playlists(playlists, category=category)

    # playlist -----------------------------------------------------------------

    def playlist(self, limit=29, **kwargs):
        category, videos = self.__client__.browse.playlist(limit=limit, **kwargs)
        return Videos(videos, limit=limit, category=category)

    # home ---------------------------------------------------------------------

    def home(self):
        return Folders(self.__client__.folders())

    # feed ---------------------------------------------------------------------

    def feed(self, limit=29, **kwargs):
        return Videos(self.__client__.feed.feed(limit, **kwargs), limit=limit)

    def channels(self):
        return FeedChannels(self.__client__.feed.channels())

    # search -------------------------------------------------------------------

    def query(self):
        #self.logger.info(f"query()")
        return self.__client__.search.query()

    def history(self):
        #self.logger.info(f"history()")
        return Queries(self.__client__.search.history())

    def search(self, query):
        #self.logger.info(f"search(query={query})")
        return Results(
            self.__client__.search.search(query), category=query["query"]
        )
