# -*- coding: utf-8 -*-


from collections import OrderedDict

from iapc import public
from iapc.tools import save, Persistent


# ------------------------------------------------------------------------------
# MyChannelFeed

class MyChannelFeed(Persistent, OrderedDict):

    @save
    def add(self, key, value):
        self[key] = value

    @save
    def remove(self, *keys):
        for key in keys:
            del self[key]

    @save
    def update(self, others):
        super(MyChannelFeed, self).update(others)

    @save
    def clear(self):
        super(MyChannelFeed, self).clear()

    def keys(self):
        return list(super(MyChannelFeed, self).keys())

    def values(self):
        return list(super(MyChannelFeed, self).values())


# ------------------------------------------------------------------------------
# MySearchCache

class MySearchCache(Persistent, list):

    @save
    def clear(self):
        super(MySearchCache, self).clear()

    @save
    def push(self, item):
        super(MySearchCache, self).append(item)

    @save
    def pop(self):
        return super(MySearchCache, self).pop()


# ------------------------------------------------------------------------------
# MySearchHistory

class MySearchHistory(Persistent, dict):

    def __missing__(self, key):
        self[key] = OrderedDict()
        return self[key]

    @public
    @save
    def record(self, type, query, sort_by):
        self[type][query] = {"type": type, "query": query, "sort_by": sort_by}

    @public
    @save
    def remove(self, type, query):
        del self[type][query]

    @public
    @save
    def clear(self, type=None):
        if type:
            self[type].clear()
        else:
            super(MySearchHistory, self).clear()

    @public
    def values(self, type=None):
        if type:
            values = self[type].values()
        else:
            values = super(MySearchHistory, self).values()
        return list(values)
