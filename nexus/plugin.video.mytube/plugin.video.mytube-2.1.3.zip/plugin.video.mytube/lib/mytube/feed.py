# -*- coding: utf-8 -*-


from time import time

from iapc import public, Client
from iapc.tools import selectDialog

from .persistence import MyChannelFeed


# ------------------------------------------------------------------------------
# MyFeed

class MyFeed(object):

    def __init__(self, timeout=1800):
        super(MyFeed, self).__init__()
        self.__channels__ = MyChannelFeed()
        self.__timeout__ = timeout
        self.__last__ = time()
        self.__keys__ = None
        self.__contents__ = []

    def __invalid__(self, keys):
        return (self.__keys__ != keys)

    def __expired__(self):
        return ((time() - self.__last__) > self.__timeout__)

    def invalid(self):
        if (invalid := self.__invalid__(keys := set(self.__channels__.keys()))):
            self.__keys__ = keys
        if (invalid or self.__expired__()):
            return self.__keys__

    def update(self, feeds):
        self.__contents__ = sorted(
            feeds, key=lambda x: x["publishDate"], reverse=True
        )
        self.__last__ = time()

    def page(self, limit, page):
        return {
            "contents": self.__contents__[(limit * (page - 1)):(limit * page)],
            "continuation": None
        }

    # public methods -----------------------------------------------------------

    @public
    def add(self, key, value):
        self.__channels__.add(key, value)

    @public
    def remove(self, *keys):
        self.__channels__.remove(*keys)

    @public
    def keys(self):
        return self.__channels__.keys()

    @public
    def values(self):
        return self.__channels__.values()


# scripts ----------------------------------------------------------------------

client = Client()


def addChannelToFeed(channelId, author):
    client.feed.add(channelId, author)


def removeChannelsFromFeed():
    if (indices := selectDialog(client.feed.values(), heading=30001, multi=True)):
        keys = client.feed.keys()
        client.feed.remove(*(keys[index] for index in indices))

