# -*- coding: utf-8 -*-


from re import sub
from time import time

from feedparser import parse

from iapc.tools import buildUrl, Logger


# ------------------------------------------------------------------------------

def getData(data, *args):
    for key, default in args:
        try:
            data = data.__getitem__(key)
        except (KeyError, IndexError):
            data = default
    return data


def joinRuns(runs):
    return "".join((run["text"] for run in runs))


def getUrl(url):
    if url.startswith("//"):
        url = f"https:{url}"
    return url


def getThumbnail(obj):
    return getUrl(obj["thumbnails"][-1]["url"])


def getLengthSeconds(string):
    # https://stackoverflow.com/a/6403077
    seconds = 0
    for part in string.split(":"):
        seconds = (seconds * 60) + int(sub(r",|\.|\s", "", part), 10)
    return seconds
    # https://stackoverflow.com/a/6402934
    #return sum(
    #    int(x, 10) * 60 ** i for i, x in enumerate(reversed(string.split(":")))
    #)


# ------------------------------------------------------------------------------

def renderContinuationItem(obj):
    #return getData(
    #    obj, ("continuationEndpoint", {}), ("continuationCommand", None)
    #)
    return getData(
        obj,
        ("continuationEndpoint", {}),
        ("continuationCommand", {}),
        ("token", None)
    )

def videoIsLive(obj):
    for overlay in obj.get("thumbnailOverlays", []):
        if (
            getData(
                overlay,
                ("thumbnailOverlayTimeStatusRenderer", {}),
                ("style", "")
            ) == "LIVE"
        ):
            return True
    return False

def renderVideo(obj):
    video = {
        "videoId": obj["videoId"],
        "title": joinRuns(obj["title"]["runs"]),
        "thumbnail": getThumbnail(obj["thumbnail"]),
        "isLive": videoIsLive(obj),
        #"obj": obj
    }
    if (length := obj.get("lengthText")):
        video["lengthSeconds"] = getLengthSeconds(length.get("simpleText", ""))
    if (viewCount := obj.get("viewCountText")):
        video["viewCountText"] = viewCount.get("simpleText")
    if (publishedTime := obj.get("publishedTimeText")):
        video["publishedTimeText"] = publishedTime.get("simpleText")
    if (description := obj.get("descriptionSnippet")):
        video["description"] = joinRuns(description["runs"])
    return video

def getReel(obj):
    return getData(
        obj,
        ("navigationEndpoint", {}),
        ("reelWatchEndpoint", {}),
        ("overlay", {}),
        ("reelPlayerOverlayRenderer", {}),
        ("reelPlayerHeaderSupportedRenderers", {}),
        ("reelPlayerHeaderRenderer", {})
    )

def renderReelItem(obj, reel=None):
    reel = reel or getReel(obj)
    short = {
        "videoId": obj["videoId"],
        "title": obj["headline"].get("simpleText"),
        "thumbnail": getThumbnail(obj["thumbnail"]),
        "viewCountText": obj["viewCountText"].get("simpleText"),
        #"reel": reel,
        #"obj": obj
    }
    if (publishedTime := reel.get("timestampText")):
        short["publishedTimeText"] = publishedTime.get("simpleText")
    return short

def renderPlaylistVideo(obj):
    author = obj["shortBylineText"]["runs"][0]
    video = {
        "videoId": obj["videoId"],
        "title": joinRuns(obj["title"]["runs"]),
        "thumbnail": getThumbnail(obj["thumbnail"]),
        "index": int(obj["index"].get("simpleText", -1)),
        "channelId": author["navigationEndpoint"]["browseEndpoint"]["browseId"],
        "author": author["text"],
        "isLive": videoIsLive(obj),
        #"obj": obj
    }
    if (lengthSeconds := obj.get("lengthSeconds")):
        video["lengthSeconds"] = int(lengthSeconds)
    if (videoInfo := obj.get("videoInfo")):
        video["videoInfo"] = (
            videoInfo.get("simpleText") or joinRuns(videoInfo["runs"])
        )
    return video

def renderChannel(obj):
    channel = {
        "channelId": obj["channelId"],
        "author": obj["title"].get("simpleText"),
        "thumbnail": getThumbnail(obj["thumbnail"]),
        #"obj": obj
    }
    if (subscriberCount := obj.get("videoCountText")):
        channel["subscriberCountText"] = subscriberCount.get("simpleText")
    if (description := obj.get("descriptionSnippet")):
        channel["description"] = joinRuns(description["runs"])
    return channel

def renderPlaylist(obj):
    author = obj["shortBylineText"]["runs"][0]
    playlist = {
        "playlistId": obj["playlistId"],
        "title": obj["title"].get("simpleText"),
        "thumbnail": getThumbnail(obj["thumbnails"][0]),
        "videoCountText": joinRuns(obj["videoCountText"]["runs"]),
        "channelId": author["navigationEndpoint"]["browseEndpoint"]["browseId"],
        "author": author["text"],
        #"obj": obj
    }
    if (publishedTime := obj.get("publishedTimeText")):
        playlist["publishedTimeText"] = publishedTime.get("simpleText")
    return playlist

def renderGridPlaylist(obj):
    playlist = {
        "playlistId": obj["playlistId"],
        "title": joinRuns(obj["title"]["runs"]),
        "thumbnail": getThumbnail(obj["thumbnail"]),
        "videoCountText": joinRuns(obj["videoCountText"]["runs"]),
        #"obj": obj
    }
    if (publishedTime := obj.get("publishedTimeText")):
        playlist["publishedTimeText"] = publishedTime.get("simpleText")
    return playlist

def renderRichItem(obj, **defaults):
    return renderItem(obj["content"])

__renderers__ = {
    "videoRenderer": renderVideo,
    "reelItemRenderer": renderReelItem,
    "playlistVideoRenderer": renderPlaylistVideo,
    "channelRenderer": renderChannel,
    "playlistRenderer": renderPlaylist,
    "gridPlaylistRenderer": renderGridPlaylist,
    "richItemRenderer": renderRichItem
}

def renderItem(data, **defaults):
    for key, renderer in __renderers__.items():
        if (obj := data.get(key)):
            return dict(renderer(obj), **defaults)

def renderContent(data, **defaults):
    if (obj := data.get("continuationItemRenderer")):
        return (None, ("continuation", renderContinuationItem(obj)))
    return (renderItem(data, **defaults), None)


# ------------------------------------------------------------------------------

def wrapResults(func):
    def wrapper(*results):
        return (func(result) for result in results)
    return wrapper

@wrapResults
def extractVideo(obj):
    author = obj["ownerText"]["runs"][0]
    return dict(
        renderVideo(obj),
        channelId=author["navigationEndpoint"]["browseEndpoint"]["browseId"],
        author=author["text"]
    )

def extractReelShelf(results):
    for item in results["items"]:
        if (obj := item.get("reelItemRenderer")):
            reel = getReel(obj)
            if (endPoint := reel.get("channelNavigationEndpoint")):
                yield dict(
                    renderReelItem(obj, reel=reel),
                    channelId=endPoint["browseEndpoint"]["browseId"],
                    author=joinRuns(reel["channelTitleText"]["runs"])
                )

#def extractItem(*results, **defaults):
#    return (renderItem(obj, **defaults) for obj in results)

__extractors__ = {
    "videos": (
        ("videoRenderer", extractVideo),
        ("reelShelfRenderer", extractReelShelf)
    ),
    "channels": (("channelRenderer", wrapResults(renderChannel)),),
    "playlists": (("playlistRenderer", wrapResults(renderPlaylist)),)
}

def extractResults(extractors, results):
    contents = []
    for obj in results:
        for key, extractor in extractors:
            if (renderer := obj.get(key)):
                try:
                    content = extractor(renderer)
                except Exception:
                    continue
                else:
                    contents.extend(content)
    return contents


# ------------------------------------------------------------------------------
# MyContents

class MyContents(dict):

    def __init__(self, data, **defaults):
        contents = []
        items = {"continuation": None}
        for obj in data:
            #try:
            #    content, item = renderContent(obj, **defaults)
            #except Exception:
            #    continue
            #else:
            #    if content:
            #        contents.append(content)
            #    if item:
            #        k, v = item
            #        items[k] = v
            content, item = renderContent(obj, **defaults)
            if content:
                contents.append(content)
            if item:
                k, v = item
                items[k] = v
        super(MyContents, self).__init__(items, contents=contents)


# ------------------------------------------------------------------------------
# MyResults

class MyResults(dict):

    def __init__(self, results, type, limit=10):
        continuation = None
        try:
            continuation = renderContinuationItem(
                results[1].get("continuationItemRenderer", {})
            )
        except IndexError:
            pass
        contents = extractResults(
            __extractors__[type],
            getData(results[0], ("itemSectionRenderer", {}), ("contents", []))
        )
        if continuation and (len(contents) < limit):
            continuation = None
        super(MyResults, self).__init__(
            continuation=continuation, contents=contents
        )


# ------------------------------------------------------------------------------
# MyChannel

class MyChannel(dict):

    def __init__(self, data, expires=1800):
        header = data["header"]["pageHeaderRenderer"]
        metadata = data["metadata"]["channelMetadataRenderer"]
        tabs = data["contents"]["twoColumnBrowseResultsRenderer"]["tabs"]
        channel = {
            "channelId": metadata["externalId"],
            "author": metadata["title"],
            "description": metadata["description"],
            "thumbnail": getUrl(metadata["avatar"]["thumbnails"][0]["url"]),
            #"videoCountText": joinRuns(header["videosCountText"]["runs"])
        }
        if (subscriberCount := header.get("subscriberCountText")):
            channel["subscriberCountText"] = subscriberCount.get("simpleText")
        super(MyChannel, self).__init__(
            channel=channel, tabs=self.extractTabs(tabs)
        )
        self.__expires__ = (int(time()) + expires)

    __defaut_args__ = (
        ("content", {}),
        ("richGridRenderer", {}),
        ("contents", [])
    )

    __tabs__ = {
        "videos": __defaut_args__,
        "shorts": __defaut_args__,
        "streams": __defaut_args__,
        "playlists": (
            ("content", {}),
            ("sectionListRenderer", {}),
            ("contents", []),
            (0, {}),
            ("itemSectionRenderer", {}),
            ("contents", []),
            (0, {}),
            ("gridRenderer", {}),
            ("items", [])
        )
    }

    def extractTabs(self, tabs):
        result = {}
        for tab in tabs:
            if (
                (renderer := tab.get("tabRenderer")) and
                (endpoint := renderer.get("endpoint")) and
                (
                    url := getData(
                        endpoint,
                        ("commandMetadata", {}),
                        ("webCommandMetadata", {}),
                        ("url", None)
                    )
                ) and
                ((name := url.split("/")[-1]) in self.__tabs__) and
                (params := endpoint.get("browseEndpoint"))
            ):
                result[name] = {
                    "title": renderer["title"],
                    "params": params
                }
        return result

    def tabData(self, key, data):
        tabs = getData(
            data,
            ("contents", {}),
            ("twoColumnBrowseResultsRenderer", {}),
            ("tabs", [])
        )
        if tabs:
            for tab in tabs:
                if (
                    (renderer := tab.get("tabRenderer")) and
                    (renderer.get("selected", False))
                ):
                    return getData(renderer, *self.__tabs__[key])

    def tabContents(self, data):
        return MyContents(
            data,
            channelId=self["channel"]["channelId"],
            author=self["channel"]["author"]
        )


# ------------------------------------------------------------------------------
# MyPlaylist

class MyPlaylist(dict):

    def __init__(self, data, expires=1800):
        header = data["header"]["playlistHeaderRenderer"]
        microformat = data["microformat"]["microformatDataRenderer"]
        playlist = {
            "playlistId": header["playlistId"],
            "title": header["title"].get("simpleText"),
            "videoCountText": joinRuns(header["numVideosText"]["runs"]),
            "viewCountText": header["viewCountText"].get("simpleText"),
            "thumbnail": getThumbnail(microformat["thumbnail"]),
            #"header": header,
            #"microformat": microformat,
            #"data": data
        }
        if (ownerEndpoint := header.get("ownerEndpoint")):
            playlist["channelId"] = ownerEndpoint["browseEndpoint"]["browseId"]
        if (ownerText := header.get("ownerText")):
            playlist["author"] = joinRuns(ownerText["runs"])
        if (description := header.get("descriptionText")):
            playlist["description"] = description.get("simpleText")
        super(MyPlaylist, self).__init__(
            playlist=playlist,
            videos=MyContents(
                getData(
                    data,
                    ("contents", {}),
                    ("twoColumnBrowseResultsRenderer", {}),
                    ("tabs", []),
                    (0, {}),
                    ("tabRenderer", {}),
                    ("content", {}),
                    ("sectionListRenderer", {}),
                    ("contents", []),
                    (0, {}),
                    ("itemSectionRenderer", {}),
                    ("contents", []),
                    (0, {}),
                    ("playlistVideoListRenderer", {}),
                    ("contents", [])
                )
            )
        )
        self.__expires__ = (int(time()) + expires)


# ------------------------------------------------------------------------------
# MyRss

class MyRss(list):

    #def __init__(self, feed, expires=1800):
    def __init__(self, feed):
        super(MyRss, self).__init__(
            (
                {
                    "videoId": entry["yt_videoid"],
                    "title": entry["title"],
                    "description": entry["summary"],
                    "thumbnail": entry["media_thumbnail"][0]["url"],
                    "channelId": entry["yt_channelid"],
                    "author": entry["author"],
                    #"lengthSeconds": -1,
                    "publishDate": entry["published"],
                    "viewCount": entry["media_statistics"]["views"]
                }
                for entry in parse(feed)["entries"]
            )
        )
        #self.__expires__ = (int(time()) + expires)


# ------------------------------------------------------------------------------
# MyVideo

class MyVideo(dict):

    def __init__(self, playUrl, jsUrl, data):
        videoDetails = data["videoDetails"]
        microformat = data["microformat"]["playerMicroformatRenderer"]
        #playData = data["streamingData"]
        playData = data.get("streamingData", {"expiresInSeconds": 5})
        videoId = videoDetails["videoId"]
        lengthSeconds = int(videoDetails["lengthSeconds"])
        isLive = videoDetails.get("isLive", False)
        super(MyVideo, self).__init__(
            video={
                "videoId": videoId,
                "title": videoDetails["title"],
                "thumbnail": getThumbnail(videoDetails["thumbnail"]),
                "publishDate": microformat["publishDate"], # XXX: publishedTimeText
                "viewCount": videoDetails["viewCount"], # XXX: viewCountText
                "lengthSeconds": lengthSeconds,
                "description": videoDetails["shortDescription"],
                "channelId": videoDetails["channelId"],
                "author": videoDetails["author"],
                "isLive": isLive,
                "playUrl": buildUrl(playUrl, id=videoId)
            },
            play=dict(
                playData,
                isLive=isLive,
                jsUrl=jsUrl,
                lengthSeconds=lengthSeconds,
                status=data["playabilityStatus"]
            )
        )
        self.__expires__ = (int(time()) + int(playData["expiresInSeconds"]))


# ------------------------------------------------------------------------------
# MyTrending

def renderTrendingTab(obj):
    return extractTrending(
        *getData(
            obj,
            ("content", {}),
            ("sectionListRenderer", {}),
            ("contents", [])
        )
    )

def renderItemSection(obj):
    return extractTrending(*obj.get("contents", []))

def renderShelf(obj):
    return extractTrending(
        *getData(
            obj,
            ("content", {}),
            ("expandedShelfContentsRenderer", {}),
            ("items", [])
        )
    )

__trendingRenderers__ = {
    "tabRenderer": renderTrendingTab,
    "itemSectionRenderer": renderItemSection,
    "shelfRenderer": renderShelf,
    "reelShelfRenderer": extractReelShelf,
    "videoRenderer": extractVideo
}

def extractTrending(*items):
    results = []
    for item in items:
        for key, renderer in __trendingRenderers__.items():
            if (obj := item.get(key)):
                results.extend(renderer(obj))
                break
        else:
            results.append(item)
    return results

class MyTrending(dict):

    def __init__(self, data, expires=1800):
        header = data["header"]["c4TabbedHeaderRenderer"]
        tabs = data["contents"]["twoColumnBrowseResultsRenderer"]["tabs"]
        selected, folders = self.extractTabs(tabs)
        channel = {
            "title": header["title"],
            "thumbnail": getUrl(header["avatar"]["thumbnails"][0]["url"]),
            "selected": selected,
            #"data": data
        }
        videos = {
            "continuation": None,
            "contents": self.extractVideos(tabs)
        }
        super(MyTrending, self).__init__(
            channel=channel, folders=folders, videos=videos
        )
        self.__expires__ = (int(time()) + expires)

    def extractTabs(self, tabs):
        selected = None
        folders = []
        for tab in tabs:
            if (
                (renderer := tab.get("tabRenderer")) and
                (endpoint := renderer.get("endpoint")) and
                (browseEndpoint := endpoint.get("browseEndpoint"))
            ):
                folder = {
                    "type": "trending",
                    "title": renderer["title"],
                    "kwargs": {
                        "params": browseEndpoint.get("params", "")
                    },
                    #"tab": tab
                }
                if(renderer.get("selected", False)):
                    selected = folder
                else:
                    folders.append(folder)
        return selected, folders

    def extractVideos(self, tabs):
        for tab in tabs:
            if tab.get("tabRenderer", {}).get("selected", False):
                return extractTrending(tab)
        return []


# ------------------------------------------------------------------------------
# MyGenerated

class MyGenerated(dict):

    def __init__(self, data, expires=1800):
        try:
            metadata = data["metadata"]["channelMetadataRenderer"]
            channelId = metadata["externalId"]
            title = metadata["title"]
        except KeyError:
            metadata = getData(
                data,
                ("header", {}),
                ("carouselHeaderRenderer", {}),
                ("contents", []),
                (-1, {}),
                ("topicChannelDetailsRenderer", {})
            )
            channelId = metadata["navigationEndpoint"]["browseEndpoint"]["browseId"]
            title = metadata["title"].get("simpleText")
        thumbnail = getUrl(metadata["avatar"]["thumbnails"][-1]["url"])
        channel = dict(
            channelId=channelId, title=title, thumbnail=thumbnail
        )
        contents = self.extractContents(
            data["contents"]["twoColumnBrowseResultsRenderer"]["tabs"]
        )
        super(MyGenerated, self).__init__(
            channel=channel, contents=contents,
            #metadata=metadata,
            #data=data
        )
        self.__expires__ = (int(time()) + expires)

    def extractPlaylists(self, contents):
        for content in contents:
            if (
                (
                    renderer := getData(
                        content,
                        ("itemSectionRenderer", {}),
                        ("contents", []),
                        (0, {}),
                        ("shelfRenderer", None),
                    )
                ) and
                (endpoint := renderer.get("endpoint")) and
                (
                    (
                        pageType := getData(
                            endpoint,
                            ("commandMetadata", {}),
                            ("webCommandMetadata", {}),
                            ("webPageType", None)
                        )
                    ) == "WEB_PAGE_TYPE_PLAYLIST"
                ) and
                (browseEndpoint := endpoint.get("browseEndpoint"))
            ):
                yield browseEndpoint["browseId"][2:]

    def extractContents(self, tabs):
        for tab in tabs:
            if (
                (renderer := tab.get("tabRenderer")) and
                (renderer.get("selected", False)) and
                (
                    contents := getData(
                        renderer,
                        ("content", {}),
                        ("sectionListRenderer", {}),
                        ("contents", None)
                    )
                )
            ):
                return list(self.extractPlaylists(contents))
        return []
