# -*- coding: utf-8 -*-


from yt_dlp import YoutubeDL

from iapc import Client


# ------------------------------------------------------------------------------
# MyYtDlp

class MyYtDlp(object):

    __service_id__ = "service.yt-dlp"

    def __init__(self, logger):
        self.logger = logger.getLogger(f"{logger.component}.ytdlp")
        self.__infos__ = YoutubeDL()
        self.__client__ = Client(self.__service_id__)

    def __setup__(self):
        pass

    def __stop__(self):
        self.__infos__.close()
        self.logger.info("stopped")

    # --------------------------------------------------------------------------

    def video(self, url):
        #self.logger.info(f"video(url={url})")
        return self.__client__.video(url)

    def extract(self, url):
        #self.logger.info(f"extract(url={url})")
        return self.__infos__.extract_info(url, download=False, process=False)
