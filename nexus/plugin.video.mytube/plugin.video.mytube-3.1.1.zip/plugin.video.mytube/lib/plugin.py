# -*- coding: utf-8 -*-


from sys import argv
from urllib.parse import urlencode

from inputstreamhelper import Helper

from iapc.tools import action, getSetting, openSettings, parseQuery, Plugin

from mytube.client import client
from mytube.search import newSearch, searchHistory, sortBy
from mytube.utils import moreItem, newSearchItem, settingsItem


# ------------------------------------------------------------------------------
# MyPlugin

class MyPlugin(Plugin):

    # dispatch -----------------------------------------------------------------

    def dispatch(self, **kwargs):
        super(MyPlugin, self).dispatch(**kwargs)
        client.pushQuery(kwargs)

    # helpers ------------------------------------------------------------------

    def addDirectory(self, items, *args, **kwargs):
        if super(MyPlugin, self).addDirectory(items, *args):
            if (more := getattr(items, "more", None)):
                return self.addMore(more, **kwargs)
            return True
        return False

    def addMore(self, more, **kwargs):
        if more is True:
            kwargs["page"] = int(kwargs.get("page", 1)) + 1
        else:
            kwargs["continuation"] = more
        return self.addItem(
            moreItem(self.url, action=self.action, **kwargs)
        )

    def addNewSearch(self, **kwargs):
        return self.addItem(
            newSearchItem(self.url, action="search", new=True, **kwargs)
        )

    def addSettings(self):
        if getSetting("settings", bool):
            return self.addItem(settingsItem(self.url, action="settings"))
        return True

    def playItem(
        self, item, manifestType, mimeType=None, headers=None, params=None
    ):
        if not Helper(manifestType).check_inputstream():
            return False
        item.setProperty("inputstream", "inputstream.adaptive")
        item.setProperty("inputstream.adaptive.manifest_type", manifestType)
        if headers and isinstance(headers, dict):
            item.setProperty(
                "inputstream.adaptive.manifest_headers", urlencode(headers)
            )
        if params and isinstance(params, dict):
            item.setProperty(
                "inputstream.adaptive.manifest_params", urlencode(params)
            )
        return super(MyPlugin, self).playItem(item, mimeType=mimeType)

    # play ---------------------------------------------------------------------

    @action()
    def video(self, **kwargs):
        item, manifestType, params = client.play(kwargs["id"])
        if item:
            return self.playItem(item, manifestType, **params)
        return False

    # channel ------------------------------------------------------------------

    @action()
    def channel(self, **kwargs):
        if (
            (not ("continuation" in kwargs)) and
            (tabs := client.tabs("videos", **kwargs)) and
            (not self.addItems(tabs))
        ):
            return False
        return self.addDirectory(client.videos(**kwargs), "video", **kwargs)

    @action(category=30007)
    def shorts(self, **kwargs):
        return self.addDirectory(client.shorts(**kwargs), "video", **kwargs)

    @action(category=30008)
    def streams(self, **kwargs):
        return self.addDirectory(client.streams(**kwargs), "video", **kwargs)

    @action(category=30005)
    def playlists(self, **kwargs):
        return self.addDirectory(
            client.playlists(**kwargs), "playlist", **kwargs
        )

    # playlist -----------------------------------------------------------------

    @action()
    def playlist(self, **kwargs):
        return self.addDirectory(client.playlist(**kwargs), "video", **kwargs)

    # home ---------------------------------------------------------------------

    @action()
    def home(self, **kwargs):
        if self.addDirectory(client.home()):
            return self.addSettings()
        return False

    # feed ---------------------------------------------------------------------

    @action(category=30001)
    def feed(self, **kwargs):
        return self.addDirectory(client.feeds(**kwargs), "video", **kwargs)

    # search -------------------------------------------------------------------

    def __search__(self, query, **kwargs):
        client.searchCache.push((query, kwargs))
        return self.addDirectory(
            *client.search(query, **kwargs), query=query, **kwargs
        )

    def __new_search__(self, history=False, **kwargs):
        try:
            query, kwargs = client.searchCache.pop()
        except IndexError:
            index = getSetting("sort_by", int)
            try:
                sort_by = list(sortBy.keys())[index]
            except IndexError:
                sort_by = None
            query, kwargs["sort_by"] = newSearch(
                kwargs["type"], sort_by=sort_by, history=history
            )
        if query:
            return self.__search__(query, **kwargs)
        return False

    def __history__(self, **kwargs):
        client.searchCache.clear()
        if self.addNewSearch(**kwargs):
            return self.addItems(searchHistory(kwargs["type"]))
        return False

    @action(category=30002)
    def search(self, **kwargs):
        history = getSetting("history", bool)
        if "type" in kwargs:
            new = kwargs.pop("new", False)
            if (query := kwargs.pop("query", None)):
                return self.__search__(query, **kwargs)
            if new:
                return self.__new_search__(history=history, **kwargs)
            return self.__history__(**kwargs)
        client.searchCache.clear()
        return self.addItems(
            client.subFolders("search", new=(not history))
        )

    # settings -----------------------------------------------------------------

    @action(directory=False)
    def settings(self, **kwargs):
        openSettings()
        return True


# __main__ ---------------------------------------------------------------------

def dispatch(url, handle, query, *args):
    MyPlugin(url, int(handle)).dispatch(**parseQuery(query))


if __name__ == "__main__":
    dispatch(*argv)
