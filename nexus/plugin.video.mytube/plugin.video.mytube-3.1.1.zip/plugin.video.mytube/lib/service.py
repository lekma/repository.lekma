# -*- coding: utf-8 -*-


from iapc import public, Service
from iapc.tools import containerRefresh, getSetting, makeProfile

from mytube.feed import MyFeed
from mytube.folders import home, subFolders
from mytube.httpd import MyServer
from mytube.persistence import MySearchHistory
from mytube.search import clearSearchHistory


# ------------------------------------------------------------------------------
# MyService

class MyService(Service):

    def __init__(self, feed, *args, **kwargs):
        super(MyService, self).__init__(*args, **kwargs)
        makeProfile()
        self.__feed__ = feed
        self.__home__ = home
        self.__subFolders__ = subFolders
        self.__query__ = {}

    def __setup__(self):
        self.__history__ = getSetting("history", bool)

    def serve_forever(self, timeout):
        self.__httpd__ = MyServer(self.id, timeout=timeout)
        while not self.waitForAbort(timeout):
            self.__httpd__.handle_request()
        self.__httpd__.server_close()

    def start(self, **kwargs):
        self.logger.info("starting...")
        self.__setup__()
        self.serve(**kwargs)
        self.logger.info("stopped")

    def onSettingsChanged(self):
        if self.__history__ and not getSetting("history", bool):
            update = (
                (self.__query__.get("action") == "search") and
                (len(self.__query__) > 1)
            )
            clearSearchHistory(update=update)
        self.__setup__()
        self.__httpd__.__setup__()
        containerRefresh()

    # public api ---------------------------------------------------------------

    @public
    def home(self):
        return self.__home__

    @public
    def subFolders(self):
        return self.__subFolders__

    @public
    def pushQuery(self, query):
        self.__query__ = query

    # infos --------------------------------------------------------------------

    @public
    def infos(self, *args):
        return self.__httpd__.__infos__(*args)

    # play ---------------------------------------------------------------------

    @public
    def play(self, id):
        if ((video := self.__httpd__.__video__(id))["isLive"]):
            manifestType, mimeType = ("hls", "application/x-mpegURL")
        else:
            manifestType, mimeType = ("mpd", "application/dash+xml")
        return (video, manifestType, {"mimeType": mimeType})

    # channel ------------------------------------------------------------------

    @public
    def channel(self, id):
        return self.__httpd__.__channel__(id)["channel"]

    @public
    def tabs(self, *args, **kwargs):
        return [
            dict(v, type=k)
            for k, v in self.__httpd__.__channel__(kwargs["id"])["tabs"].items()
            if k not in args
        ]

    @public
    def tab(self, key, **kwargs):
        channel, videos = self.__httpd__.__tab__(
            kwargs.pop("id"), key, **kwargs
        )
        return (channel["author"], videos)

    @public
    def playlists(self, **kwargs):
        channel, playlists = self.__httpd__.__playlists__(
            kwargs.pop("id"), **kwargs
        )
        return (channel["author"], playlists)

    # playlist -----------------------------------------------------------------

    @public
    def playlist(self, **kwargs):
        playlist, videos = self.__httpd__.__playlist__(
            kwargs.pop("id"), **kwargs
        )
        return (playlist["title"], videos)

    # feeds --------------------------------------------------------------------

    @public
    def feeds(self, limit, page=1, **kwargs):
        if (
            ((page := int(page)) == 1) and
            ((keys := self.__feed__.invalid()) is not None)
        ):
            self.__feed__.update(self.__httpd__.__feeds__(*keys))
        return self.__feed__.page(limit, page)

    # search -------------------------------------------------------------------

    @public
    def search(self, query, type="videos", **kwargs):
        return self.__httpd__.__search__(type, query=query, **kwargs)

    # trending -----------------------------------------------------------------

    @public
    def trending(self, params=""):
        channel, videos, folders = self.__httpd__.__trending__(params)
        return (channel["selected"]["title"], videos, folders)


# __main__ ---------------------------------------------------------------------

if __name__ == "__main__":
    MyService(feed := MyFeed()).start(
        timeout=0.5, feed=feed, history=MySearchHistory()
    )
