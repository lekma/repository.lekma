# -*- coding: utf-8 -*-


from requests import Session, Timeout

from iapc.tools import buildUrl, getSetting, localizedString, notify, ICONERROR

from .find import __find__, find, findIter, PatternsError


# ------------------------------------------------------------------------------
# HttpSession

class HttpSession(Session):

    def __init__(self, logger, name, headers=None):
        super(HttpSession, self).__init__()
        self.logger = logger.getLogger(name)
        if headers:
            self.headers.update(headers)

    def __setup__(self):
        if (timeout := getSetting("timeout", float)) <= 0.0:
            self.__timeout__ = None
        else:
            self.__timeout__ = (((timeout - (timeout % 3)) + 0.05), timeout)
        self.logger.info(f"{localizedString(30128)}: {self.__timeout__}")

    def request(self, method, url, **kwargs):
        self.logger.info(
            f"request: {method} {buildUrl(url, **kwargs.get('params', {}))}"
        )
        try:
            response = super(HttpSession, self).request(
                method, url, timeout=self.__timeout__, **kwargs
            )
        except Timeout as error:
            self.logger.error(message := f"error: {error}")
            notify(message, icon=ICONERROR)
        else:
            response.raise_for_status()
            return response


# ------------------------------------------------------------------------------
# YouTubeSession

class YouTubeSession(HttpSession):

    __headers__ = {
    }
    __url__ = "https://www.youtube.com"

    def __init__(self, logger, name):
        self.__inner__ = {}
        self.__params__ = {}
        super(YouTubeSession, self).__init__(
            logger, name, headers=self.__headers__
        )

    def __setup__(self):
        self.cookies.clear()
        self.__inner__ = {}
        self.__params__["hl"] = getSetting("hl", str)
        self.logger.info(
            f"{localizedString(30124)}: {getSetting('hl.text', str)}"
        )
        self.__params__["gl"] = getSetting("gl", str)
        self.logger.info(
            f"{localizedString(30126)}: {getSetting('gl.text', str)}"
        )
        super(YouTubeSession, self).__setup__()

    def request(self, method, url, **kwargs):
        return super(YouTubeSession, self).request(
            method, f"{self.__url__}{url}", **kwargs
        )

    def __get__(self, url, **kwargs):
        kwargs.setdefault("params", {}).update(self.__params__)
        return super(YouTubeSession, self).get(url, **kwargs).text

    @property
    def __consent__(self):
        return ((consent := self.cookies.get("CONSENT")) and ("YES" in consent))

    def __setup_consent__(self):
        try:
            value = __find__(self.__get__("/"), r'cb\..+?(?=\")').group()
        except PatternsError:
            if (
                (consent := self.cookies.get("CONSENT")) and
                ("PENDING" in consent)
            ):
                cid = consent.split("+")[1]
            else:
                cid = randint(100, 999)
            value = f"cb.20221213-07-p1.en+FX+{cid}"
        self.cookies.set("CONSENT", f"YES+{value}", domain=".youtube.com")

    def get(self, url, **kwargs):
        if (not self.__consent__):
            self.__setup_consent__()
        return self.__get__(url, **kwargs)

    # innertube ----------------------------------------------------------------

    def __setup_inner__(self):
        config = findIter(self.get("/"), r"ytcfg\.set\s*\(\s*")
        self.__inner__["url"] = f"/youtubei/{config['INNERTUBE_API_VERSION']}"
        self.__inner__["jsUrl"] = config["PLAYER_JS_URL"]
        self.__inner__["params"] = {
            "key": config["INNERTUBE_API_KEY"],
            "prettyPrint": False
        }
        self.__inner__["headers"] = {
            #"X-Goog-Visitor-Id": config["VISITOR_DATA"],
            "X-Youtube-Client-Name": str(config["INNERTUBE_CONTEXT_CLIENT_NAME"]),
            "X-Youtube-Client-Version": config["INNERTUBE_CONTEXT_CLIENT_VERSION"]
        }
        self.__inner__["context"] = {
            "client": {
                "hl": self.__params__["hl"],
                "gl": self.__params__["gl"],
                #"userAgent": self.headers["User-Agent"],
                "clientName": config["INNERTUBE_CLIENT_NAME"],
                "clientVersion": config["INNERTUBE_CLIENT_VERSION"]
            }
        }

    def __innertube__(self, url, **kwargs):
        self.logger.info(f"__innertube__(url={url}, kwargs={kwargs})")
        if (not self.__inner__):
            self.__setup_inner__()
        return self.post(
            f"{self.__inner__['url']}{url}",
            headers=self.__inner__["headers"],
            params=self.__inner__["params"],
            json=dict(kwargs, context=self.__inner__["context"])
        ).json()


# ------------------------------------------------------------------------------
# MySession

class MySession(YouTubeSession):

    def js(self, jsUrl):
        #return self.get(jsUrl)
        return self.request("GET", jsUrl).text

    def playlists(self, id, **kwargs):
        return find(
            self.get(f"/channel/{id}/playlists", params=kwargs),
            r"ytInitialData\s*=\s*"
        )

    def results(self, **kwargs):
        return find(self.get("/results", params=kwargs), r"ytInitialData\s*=\s*")

    def rss(self, **kwargs):
        return self.get("/feeds/videos.xml", params=kwargs)

    def trending(self, **kwargs):
        return find(
            self.get(f"/feed/trending", params=kwargs),
            r"ytInitialData\s*=\s*"
        )

    def watch(self, **kwargs):
        html = self.get("/watch", params=kwargs)
        #self.logger.info(f"html: {html}")
        return (
            find(html, r"PLAYER_JS_URL\s*['\"]\s*:[^'\"]*"),
            find(html, r"ytInitialPlayerResponse\s*=\s*")
        )

    # innertube ----------------------------------------------------------------

    def browse(self, **kwargs):
        return self.__innertube__("/browse", **kwargs)

    def player(self, **kwargs):
        return self.__innertube__("/player", **kwargs)

    def search(self, **kwargs):
        return self.__innertube__("/search", **kwargs)

    def __continue__(self, url, continuation):
        return self.__innertube__(url, continuation=continuation)
