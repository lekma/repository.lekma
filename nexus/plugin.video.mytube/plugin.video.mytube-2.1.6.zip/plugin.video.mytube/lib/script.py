# -*- coding: utf-8 -*-


from sys import argv
from urllib.parse import unquote_plus

from iapc.tools import (
    addFavourite, containerUpdate, getAddonId, infoDialog, playMedia
)

from mytube.client import client
from mytube.feed import addChannelToFeed, removeChannelsFromFeed
from mytube.regional import selectLanguage, selectLocation
from mytube.search import clearSearchHistory, removeSearchQuery, updateSortBy


__plugin_url__ = f"plugin://{getAddonId()}"


# channel stuff ----------------------------------------------------------------

__channel_url__ = f"{__plugin_url__}/?action=channel&id={{}}"

def goToChannel(id):
    containerUpdate(__channel_url__.format(id))

def addChannelToFavourites(id):
    channel = client.channel(id)
    addFavourite(
        channel.author, "window",
        window="videos", thumbnail=channel.thumbnail,
        windowparameter=__channel_url__.format(id)
    )


# playWithYouTube --------------------------------------------------------------

__withYoutube_url__ = "plugin://plugin.video.youtube/play/?incognito=true&video_id={}"

def playWithYouTube(id):
    playMedia(__withYoutube_url__.format(id))


# getInfos ---------------------------------------------------------------------

def getInfos(key, id):
    infoDialog(client.infos(key, id, __plugin_url__))


# __main__ ---------------------------------------------------------------------

__dispatch__ = {
    "goToChannel": goToChannel,
    "addChannelToFavourites": addChannelToFavourites,
    "playWithYouTube": playWithYouTube,
    "getInfos": getInfos,
    "selectLanguage": selectLanguage,
    "selectLocation": selectLocation,
    "addChannelToFeed": addChannelToFeed,
    "removeChannelsFromFeed": removeChannelsFromFeed,
    "clearSearchHistory": clearSearchHistory,
    "removeSearchQuery": removeSearchQuery,
    "updateSortBy": updateSortBy
}

def dispatch(name, *args):
    if (
        not (action := __dispatch__.get(name)) or
        not callable(action)
    ):
        raise Exception(f"Invalid script '{name}'")
    action(*(unquote_plus(arg) for arg in args))


if __name__ == "__main__":
    dispatch(*argv[1:])
