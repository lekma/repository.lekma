# -*- coding: utf-8 -*-


from iapc import Client
from iapc.tools import getSetting, Logger

from mytube.items import (
    Channel, Channels, Folder, Folders, Playlist, Playlists, Video, Videos
)
from mytube.persistence import MySearchCache


# ------------------------------------------------------------------------------
# MyClient

class MyClient(object):

    def __init__(self):
        self.logger = Logger(component="client")
        self.__client__ = Client()
        self.__subFolders__ = self.__client__.subFolders()
        self.__home__ = self.__client__.home()
        self.searchCache = MySearchCache()

    # home ---------------------------------------------------------------------

    def home(self):
        return Folders(
            [
                folder for folder in self.__home__
                if (
                    getSetting(folder["type"], bool)
                    if folder.get("optional", False)
                    else True
                )
            ],
            category="MyTube"
        )

    # infos --------------------------------------------------------------------

    __infos__ = {
        "channel": Channel,
        "playlist": Playlist,
        "video": Video
    }

    def infos(self, key, id, url):
        return self.__infos__[key](
            self.__client__.infos(key, id)
        ).getItem(url, key)

    # subFolders ---------------------------------------------------------------

    def subFolders(self, type, **kwargs):
        return Folders(self.__subFolders__[type], **kwargs)

    # pushQuery ----------------------------------------------------------------

    def pushQuery(self, query):
        return self.__client__.pushQuery(query)

    # feeds --------------------------------------------------------------------

    def feeds(self, limit=20, **kwargs):
        return Videos(self.__client__.feeds(limit, **kwargs), limit=limit)

    # search -------------------------------------------------------------------

    __searchActions__ = {
        "videos": (Videos, "video"),
        "channels": (Channels, "channel"),
        "playlists": (Playlists, "playlist")
    }

    def search(self, query, **kwargs):
        cls, action = self.__searchActions__[kwargs["type"]]
        return (
            cls(self.__client__.search(query, **kwargs), category=query),
            action
        )

    # play ---------------------------------------------------------------------

    def play(self, id):
        video, *args = self.__client__.play(id)
        if video:
            return (Video(video).makeItem(video["playUrl"]), *args)
        return (None, *args)

    # channel ------------------------------------------------------------------

    def channel(self, id):
        return Channel(self.__client__.channel(id))

    def tabs(self, *args, **kwargs):
        if (tabs := self.__client__.tabs(*args, **kwargs)):
            return Folders(tabs, **kwargs)

    def __tab__(self, key, **kwargs):
        category, videos = self.__client__.tab(key, **kwargs)
        return Videos(videos, category=category)

    def videos(self, **kwargs):
        return self.__tab__("videos", **kwargs)

    def shorts(self, **kwargs):
        return self.__tab__("shorts", **kwargs)

    def streams(self, **kwargs):
        return self.__tab__("streams", **kwargs)

    def playlists(self, **kwargs):
        category, playlists = self.__client__.playlists(**kwargs)
        return Playlists(playlists, category=category)

    # playlist -----------------------------------------------------------------

    def playlist(self, **kwargs):
        category, videos = self.__client__.playlist(**kwargs)
        return Videos(videos, category=category)


client = MyClient()
