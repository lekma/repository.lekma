# -*- coding: utf-8 -*-


from urllib.parse import quote_plus

from iapc.tools import (
    buildUrl, getAddonId, getSetting, localizedString, maybeLocalize, ListItem
)
from iapc.tools.objects import List, Object


# ------------------------------------------------------------------------------
# Items

class Item(Object):

    __menus__ = []

    @classmethod
    def menus(cls, **kwargs):
        return [
            (
                maybeLocalize(label).format(**kwargs),
                action.format(
                    addonId=getAddonId(),
                    **{key: quote_plus(value) for key, value in kwargs.items()}
                )
            )
            for label, action, *settings in cls.__menus__
            if all(getSetting(*iargs) == ires for iargs, ires in settings)
        ]

    @property
    def thumbnail(self):
        return self.get("thumbnail", self.__thumbnail__)

    @property
    def icon(self):
        return self.get("icon", self.__thumbnail__)


class Items(List):

    __ctor__ = Item

    def __init__(self, items, continuation=None, limit=0, **kwargs):
        super(Items, self).__init__(items, **kwargs)
        self.more = continuation or ((len(self) >= limit) if limit else False)


class Contents(Items):

    def __init__(self, items, **kwargs):
        super(Contents, self).__init__(
            items["contents"],
            continuation=items["continuation"],
            content="videos",
            **kwargs
        )


# ------------------------------------------------------------------------------
# Folders

class Folder(Item):

    __thumbnail__ = "DefaultFolder.png"

    @property
    def action(self):
        return self.get("action", self.type)

    @property
    def plot(self):
        if (plot := self.get("plot")):
            return maybeLocalize(plot)

    @property
    def art(self):
        return dict(
            {"icon": self.icon, "poster": self.thumbnail}, **self.get("art", {})
        )

    def getItem(self, url, **kwargs):
        title = maybeLocalize(self.title)
        return ListItem(
            title,
            buildUrl(url, action=self.action, **dict(self.kwargs, **kwargs)),
            isFolder=True,
            infoLabels={
                "video": {
                    "title": title,
                    "plot": self.plot or title
                }
            },
            **self.art
        )


class Folders(Items):

    __ctor__ = Folder


# ------------------------------------------------------------------------------
# Queries

class Query(Item):

    __menus__ = [
        (30130, "RunScript({addonId},updateSortBy,{type},{query},{sort_by})"),
        (30035, "RunScript({addonId},removeSearchQuery,{type},{query})"),
        (30036, "RunScript({addonId},clearSearchHistory,{type})")
    ]

    __thumbnail__ = "DefaultAddonsSearch.png"

    def getItem(self, url):
        return ListItem(
            self.query,
            buildUrl(
                url,
                action="search",
                type=self.type,
                query=self.query,
                sort_by=self.sort_by
            ),
            isFolder=True,
            infoLabels={
                "video": {
                    "title": self.query,
                    "plot": self.query
                }
            },
            contextMenus=self.menus(
                type=self.type,
                query=self.query,
                sort_by=self.sort_by
            ),
            poster=self.thumbnail,
            #thumb=self.thumbnail,
            icon=self.icon
        )


class Queries(Items):

    __ctor__ = Query


# ------------------------------------------------------------------------------
# Videos

class Video(Item):

    __menus__ = [
        (30038, "RunScript({addonId},getInfos,video,{videoId})"),
        (
            30037, "RunScript({addonId},playWithYouTube,{videoId})",
            (("withyoutube", bool), True)
        ),
        (30031, "RunScript({addonId},goToChannel,{channelId})"),
        (30032, "RunScript({addonId},addChannelToFavourites,{channelId})"),
        (
            30034, "RunScript({addonId},addChannelToFeed,{channelId},{author})",
            (("feed", bool), True)
        )
    ]

    __thumbnail__ = "DefaultAddonVideo.png"

    @property
    def __videoInfo__(self):
        info = []
        if (viewCountText := self.get("viewCountText")):
            info.append(f"{viewCountText}")
        elif (viewCount := self.get("viewCount")):
            info.append(localizedString(30054).format(viewCount))
        if (publishedTimeText := self.get("publishedTimeText")):
            info.append(f"{publishedTimeText}")
        elif (publishDate := self.get("publishDate")):
            info.append(localizedString(30055).format(publishDate))
        return " • ".join(info)

    @property
    def title(self):
        if self.get("isLive", False):
            return " ".join(("[COLOR red](₍.₎)[/COLOR]", self.get("title")))
        return self.get("title")

    @property
    def plot(self):
        plot = [f"{self.title}", f"{self.author}"]
        if (info := self.get("videoInfo", self.__videoInfo__)):
            plot.append(info)
        if (description := self.get("description")):
            plot.append(f"{description}")
        return "\n\n".join(plot)

    @property
    def duration(self):
        return self.get("lengthSeconds", -1)

    def makeItem(self, path):
        return ListItem(
            self.title,
            path,
            infoLabels={
                "video": {
                    "mediatype": "video",
                    "title": self.title,
                    "plot": self.plot
                }
            },
            streamInfos={
                "video": {
                    "duration": self.duration
                }
            },
            contextMenus=self.menus(
                channelId=self.channelId,
                author=self.author,
                videoId=self.videoId
            ),
            #poster=self.thumbnail,
            thumb=self.thumbnail,
            #icon=self.icon
        )

    def getItem(self, url, action):
        return self.makeItem(buildUrl(url, action=action, id=self.videoId))


class Videos(Contents):

    __ctor__ = Video


# ------------------------------------------------------------------------------
# Channels

class Channel(Item):

    __menus__ = [
        (30038, "RunScript({addonId},getInfos,channel,{channelId})"),
        (
            30034, "RunScript({addonId},addChannelToFeed,{channelId},{author})",
            (("feed", bool), True)
        )
    ]

    __thumbnail__ = "DefaultArtist.png"

    @property
    def channelInfo(self):
        info = []
        if (subscriberCountText := self.get("subscriberCountText")):
            info.append(f"{subscriberCountText}")
        if (videoCountText := self.get("videoCountText")):
            info.append(f"{videoCountText}")
        return " • ".join(info)

    @property
    def plot(self):
        plot = [f"{self.author}"]
        if (info := self.channelInfo):
            plot.append(info)
        if (description := self.get("description")):
            plot.append(f"{description}")
        return "\n\n".join(plot)

    def getItem(self, url, action):
        return ListItem(
            self.author,
            buildUrl(url, action=action, id=self.channelId),
            isFolder=True,
            infoLabels={
                "video": {
                    "title": self.author,
                    "plot": self.plot
                }
            },
            contextMenus=self.menus(
                channelId=self.channelId,
                author=self.author
            ),
            poster=self.thumbnail,
            #thumb=self.thumbnail,
            #icon=self.icon
        )


class Channels(Contents):

    __ctor__ = Channel


# ------------------------------------------------------------------------------
# Playlists

class Playlist(Item):

    __menus__ = [
        (30038, "RunScript({addonId},getInfos,playlist,{playlistId})"),
        (30031, "RunScript({addonId},goToChannel,{channelId})"),
        (30032, "RunScript({addonId},addChannelToFavourites,{channelId})"),
        (
            30034, "RunScript({addonId},addChannelToFeed,{channelId},{author})",
            (("feed", bool), True)
        )
    ]

    __thumbnail__ = "DefaultPlaylist.png"

    @property
    def playlistInfo(self):
        info = []
        if (videoCountText := self.get("videoCountText")):
            info.append(f"{videoCountText}")
        if (publishedTimeText := self.get("publishedTimeText")):
            info.append(f"{publishedTimeText}")
        return " • ".join(info)

    @property
    def plot(self):
        plot = [f"{self.title}", f"{self.author}"]
        if (info := self.playlistInfo):
            plot.append(info)
        if (description := self.get("description")):
            plot.append(f"{description}")
        return "\n\n".join(plot)

    def getItem(self, url, action):
        return ListItem(
            self.title,
            buildUrl(url, action=action, id=self.playlistId),
            isFolder=True,
            infoLabels={
                "video": {
                    "title": self.title,
                    "plot": self.plot
                }
            },
            contextMenus=self.menus(
                playlistId=self.playlistId,
                channelId=self.channelId,
                author=self.author
            ),
            poster=self.thumbnail,
            thumb=self.thumbnail,
            #icon=self.icon
        )


class Playlists(Contents):

    __ctor__ = Playlist
