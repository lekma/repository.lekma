# script.module.iapc

Inter-Addon Procedure Call addon for Kodi.
