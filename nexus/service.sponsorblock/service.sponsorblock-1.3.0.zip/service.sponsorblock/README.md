# service.sponsorblock

kodi service for limited support of [SponsorBlock](https://sponsor.ajay.app/).

Uses SponsorBlock data licensed used under
[CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/)
from [https://sponsor.ajay.app/](https://sponsor.ajay.app/).
