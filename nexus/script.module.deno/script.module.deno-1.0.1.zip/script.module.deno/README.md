# script.module.deno

Kodi addon for the [Deno](https://github.com/denoland/deno/) JavaScript runtime.
