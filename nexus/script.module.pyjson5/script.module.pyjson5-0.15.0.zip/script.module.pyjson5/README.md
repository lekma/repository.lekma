# script.module.pyjson5

Python [pyjson5](https://github.com/dpranke/pyjson5/) library packaged for Kodi.
