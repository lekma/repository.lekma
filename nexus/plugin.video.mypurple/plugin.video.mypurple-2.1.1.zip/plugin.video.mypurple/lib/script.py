# -*- coding: utf-8 -*-


from sys import argv
from urllib.parse import unquote_plus

from iapc.tools import getAddonId, playMedia

from mypurple.client import client


__plugin_url__ = f"plugin://{getAddonId()}"


# playFromTwitch ---------------------------------------------------------------

__fromTwitch_url__ = f"{__plugin_url__}/?action=play&twitch=true&key={{}}"

def playFromTwitch(key):
    playMedia(__fromTwitch_url__.format(key))


# __main__ ---------------------------------------------------------------------

__dispatch__ = {
    "playFromTwitch": playFromTwitch,
    "renameChannel": client.renameChannel,
    "removeChannel": client.removeChannel
}

def dispatch(name, *args):
    if (
        not (action := __dispatch__.get(name)) or
        not callable(action)
    ):
        raise Exception(f"Invalid script '{name}'")
    action(*(unquote_plus(arg) for arg in args))


if __name__ == "__main__":
    dispatch(*argv[1:])
