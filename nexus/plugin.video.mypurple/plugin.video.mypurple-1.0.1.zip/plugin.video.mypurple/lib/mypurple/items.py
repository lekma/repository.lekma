# -*- coding: utf-8 -*-


from urllib.parse import quote_plus

from iapc.tools import (
    buildUrl, getAddonId, getMedia, localizedString, maybeLocalize, ListItem
)
from iapc.tools.objects import List, Object


# misc useful items ------------------------------------------------------------

def __makeItem__(label, url, art=None, isFolder=True, **kwargs):
    label = localizedString(label)
    return ListItem(
        label,
        buildUrl(url, **kwargs),
        isFolder=isFolder,
        isPlayable=False,
        infoLabels={"video": {"title": label, "plot": label}},
        poster=art,
        icon=art
    )


# addChannel item
def addChannelItem(url, **kwargs):
    return __makeItem__(
        30002, url, art="DefaultAddSource.png", isFolder=False, **kwargs
    )


# ------------------------------------------------------------------------------
# Items

class Item(Object):

    __menus__ = []

    @classmethod
    def menus(cls, **kwargs):
        return [
            (
                maybeLocalize(label).format(**kwargs),
                action.format(
                    addonId=getAddonId(),
                    **{key: quote_plus(value) for key, value in kwargs.items()}
                )
            )
            for label, action in cls.__menus__
        ]

    @property
    def thumbnail(self):
        return self.get("thumbnail", self.__thumbnail__)

    @property
    def icon(self):
        return self.get("icon", self.__thumbnail__)


class Items(List):

    __ctor__ = Item


# ------------------------------------------------------------------------------
# Channels

class Channel(Item):

    __menus__ = [
        (30003, "RunScript({addonId},playFromTwitch,{key})"),
        (30004, "RunScript({addonId},renameChannel,{key},{name})"),
        (30005, "RunScript({addonId},removeChannel,{key})")
    ]

    __thumbnail__ = "DefaultArtist.png"

    def getItem(self, url, action):
        return ListItem(
            self.name,
            buildUrl(url, action=action, key=self.key),
            infoLabels={
                "video": {
                    "mediatype": "video",
                    "title": self.name,
                    "plot": self.name,
                    "playcount":0
                }
            },
            streamInfos={
                "video": {
                    "duration": -1
                }
            },
            contextMenus=self.menus(
                key=self.key,
                name=self.name
            ),
            poster=self.thumbnail,
            icon=self.icon
        )


class Channels(Items):

    __ctor__ = Channel
