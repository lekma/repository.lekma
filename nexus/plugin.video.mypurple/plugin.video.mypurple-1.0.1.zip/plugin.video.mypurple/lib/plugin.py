# -*- coding: utf-8 -*-


from sys import argv

from iapc.tools import action, parseQuery, Plugin

from mypurple.client import client


# ------------------------------------------------------------------------------
# MyPlugin

class MyPlugin(Plugin):

    # play ---------------------------------------------------------------------

    @action()
    def play(self, **kwargs):
        if (item := client.play(**kwargs)):
            return self.playItem(item, mimeType="application/x-mpegURL")
        return False

    # home ---------------------------------------------------------------------

    @action(category=30000)
    def home(self, **kwargs):
        item, channels = client.home(self.url, action="addChannel")
        if self.addItem(item):
            return self.addDirectory(channels, "play")
        return False

    # addChannel ---------------------------------------------------------------

    @action()
    def addChannel(self, **kwargs):
        client.addChannel()
        return True


# __main__ ---------------------------------------------------------------------

def dispatch(url, handle, query, *args):
    MyPlugin(url, int(handle)).dispatch(**parseQuery(query))


if __name__ == "__main__":
    dispatch(*argv)
