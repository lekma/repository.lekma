# -*- coding: utf-8 -*-


from collections import OrderedDict
from urllib.parse import (
    parse_qs, quote, unquote, urlencode, urlsplit, urlunsplit
)

from inputstreamhelper import Helper
from yt_dlp import YoutubeDL

from iapc.tools import (
    containerRefresh, getSetting, inputDialog, makeProfile, notify, save,
    ListItem, Logger, Persistent, ICONERROR
)

from mypurple.items import addChannelItem, Channels


# ------------------------------------------------------------------------------
# MyChannels

class MyChannels(Persistent, OrderedDict):

    @save
    def add(self, name):
        self[key] = {"key": (key := name.lower()), "name": name}

    @save
    def rename(self, key, name):
        self[key]["name"] = name

    @save
    def remove(self, *keys):
        for key in keys:
            del self[key]


# ------------------------------------------------------------------------------
# MyClient

def refresh(func):
    def wrapper(self, *args, **kwargs):
        try:
            return func(self, *args, **kwargs)
        finally:
            containerRefresh()
    return wrapper


class MyClient(object):

    def __init__(self):
        self.logger = Logger(component="client")
        makeProfile()
        self.__channels__ = MyChannels()
        self.__extractor__ = YoutubeDL(
            params={"allowed_extractors": ["twitch:stream"]}
        )
        self.__item__ = None

    # home ---------------------------------------------------------------------

    def home(self, url, **kwargs):
        if not self.__item__:
            self.__item__ = addChannelItem(url, **kwargs)
        return (
            self.__item__, Channels(reversed(self.__channels__.values()))
        )

    # channels -----------------------------------------------------------------

    @refresh
    def addChannel(self):
        if (name := inputDialog(heading=30001)):
            self.__channels__.add(name)

    @refresh
    def renameChannel(self, key, name):
        if (name := inputDialog(heading=30001, defaultt=name)):
            self.__channels__.rename(key, name)

    @refresh
    def removeChannel(self, key):
        self.__channels__.remove(key)

    # play ---------------------------------------------------------------------

    def __ttv__(self, manifest_url):
        url = urlsplit(unquote(manifest_url))
        query = parse_qs(url.query)
        query.pop("token", None)
        query.pop("sig", None)
        return (
            quote(
                urlunsplit(
                    (
                        "https",
                        "api.ttv.lol",
                        f"/playlist/{url.path.split('/')[-1]}",
                        urlencode(query, doseq=True),
                        ""
                    )
                ),
                safe="/:"
            ),
            {"X-Donate-To": "https://ttv.lol/donate"}
        )

    def __info__(self, key):
        try:
            return self.__extractor__.extract_info(
                f"https://www.twitch.tv/{key}", download=False
            )
        except Exception as error:
            notify(f"{error}", icon=ICONERROR)

    def __adaptive__(self, item, manifestType, headers=None, params=None):
        item.setProperty("inputstream", "inputstream.adaptive")
        item.setProperty("inputstream.adaptive.manifest_type", manifestType)
        if headers and isinstance(headers, dict):
            item.setProperty(
                "inputstream.adaptive.manifest_headers", urlencode(headers)
            )
        if params and isinstance(params, dict):
            item.setProperty(
                "inputstream.adaptive.manifest_params", urlencode(params)
            )
        return item

    def play(self, twitch=False, manifestType="hls", **kwargs):
        if (
            (info := self.__info__(kwargs["key"])) and
            (Helper(manifestType).check_inputstream())
        ):
            if twitch:
                url, headers = (info["url"], None)
            else:
                url, headers = self.__ttv__(info["manifest_url"])
            title = info["fulltitle"]
            return self.__adaptive__(
                ListItem(
                    title,
                    url,
                    infoLabels={
                        "video": {
                            "mediatype": "video",
                            "title": title,
                            "plot": "\n\n".join(
                                (info["title"], info["description"])
                            ),
                            "playcount":0
                        }
                    },
                    streamInfos={
                        "video": {
                            "duration": -1
                        }
                    },
                    thumb=info["thumbnail"]
                ),
                manifestType,
                headers=headers
            )


client = MyClient()
