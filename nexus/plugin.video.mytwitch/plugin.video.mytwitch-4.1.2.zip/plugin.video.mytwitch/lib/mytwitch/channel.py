# -*- coding: utf-8 -*-


from collections import deque
from urllib.parse import urljoin

import re

from m3u8 import protocol, M3U8, PlaylistList

from nuttig import buildUrl, notify, ICONWARNING


# ------------------------------------------------------------------------------
# MyDiscontinuity

class MyDiscontinuity(deque):

    __marker__ = "#EXT-X-DISCONTINUITY\n"

    def __init__(self, maxlen=5):
        super(MyDiscontinuity, self).__init__(maxlen=maxlen)
        self.__state__ = False

    def push(self, response):
        self.append(self.__marker__ in response.text)
        if (reset := (self.__state__ != (state := any(self)))):
            self.__state__ = state
        return (state, reset)


# ------------------------------------------------------------------------------
# MyPlaylist

class MyPlaylist(dict):

    @staticmethod
    def __quality__(quality):
        if quality == "chunked":
            return (float("inf"), 0)
        if quality == "audio_only":
            return (float("-inf"), 0)
        res, fps = quality.split("p")
        return (int(res), (int(fps) if fps else 0))

    def __init__(self, playlist, channel, url, key):
        super(MyPlaylist, self).__init__()
        self.__playlist__ = self.__variant__(playlist, channel, url, key)
        self.__best__ = sorted(self.keys(), key=self.__quality__)[-1]

    def __redirect__(self, playlists, channel, url, key):
        for p in playlists:
            quality = (p.stream_info.video or p.stream_info.audio)
            self[quality] = (p.uri, key)
            p.uri = buildUrl(url, "stream", channel=channel, quality=quality)
            yield p

    def __variant__(self, playlist, channel, url, key):
        playlist.playlists = PlaylistList(
            [
                p for p in self.__redirect__(
                    playlist.playlists, channel, url, key
                )
            ]
        )
        return playlist

    @property
    def content_type(self):
        return self.__playlist__.content_type

    def dumps(self):
        return self.__playlist__.dumps()

    def best(self, quality=None):
        if quality:
            try:
                return self[quality]
            except KeyError:
                pass
        return self[self.__best__]


# ------------------------------------------------------------------------------
# MyChannel

class MyChannel(object):

    __url__ = "https://www.twitch.tv"

    # --------------------------------------------------------------------------

    def __init__(self, logger, channel, url, sessions):
        self.logger = logger.getLogger(component=channel)
        self.channel = channel
        self.url = url
        self.sessions = sessions
        self.discontinuity = MyDiscontinuity()
        self.__setup__()

    # --------------------------------------------------------------------------

    __protocol__ = (
        protocol.ext_x_discontinuity_sequence,
        protocol.ext_x_discontinuity
    )

    def __parser__(self, line, lineno, data, state):
        if line.startswith(self.__protocol__):
            return True
        return False

    def __m3u8__(self, text, response):
        try:
            playlist = M3U8(
                text,
                base_uri=urljoin(response.url, "."),
                custom_tags_parser=self.__parser__
            )
            playlist.url = response.url
            playlist.content_type = response.headers["content-type"]
            return playlist
        except Exception as error:
            self.logger.error(error)

    # --------------------------------------------------------------------------

    __pattern__ = re.compile(r"CODECS=\"([^,]+)(?:,[^\"]*)?\"")

    def __fix_text__(self, lines):
        for line in lines:
            if ("audio_only" in line):
                #line = line.replace(
                #    "VIDEO", "AUDIO"
                #).replace(
                #    "AUTOSELECT=NO", "AUTOSELECT=YES"
                #).replace(
                #    "DEFAULT=NO", "DEFAULT=YES"
                #)
                line = line.replace("VIDEO", "AUDIO").replace("NO", "YES")
            elif (line.startswith(protocol.ext_x_stream_inf)):
                line = re.sub(
                    self.__pattern__,
                    f"CODECS=\"{self.__pattern__.search(line).group(1)}\"",
                    line
                )
            yield line

    def __fix_playlist__(self, text):
        if ("audio_only" in text):
            return "".join(self.__fix_text__(text.splitlines(True)))
        return text

    # --------------------------------------------------------------------------

    def __video__(self, url, key):
        return self.sessions.__video__(url, key)

    def __get__(self, url, key):
        return self.sessions.__get__(url, key)

    # --------------------------------------------------------------------------

    def __playlist__(self, url, key):
        if (response := self.__get__(url, key)):
            return self.__m3u8__(self.__fix_playlist__(response.text), response)

    def __infos__(self, url, key):
        if (
            (video := self.__video__(url, key)) and
            (playlist := self.__playlist__(video["url"], key))
        ):
            return (video, MyPlaylist(playlist, self.channel, self.url, key))
        return (None, None)

    # --------------------------------------------------------------------------

    def __setup__(self):
        url = buildUrl(self.__url__, self.channel)
        infos = self.video, playlist, _, variant = (
            *self.__infos__(url, "playlist"),
            *self.__infos__(url, "variant")
        )
        if all(infos):
            self.playlists = {"playlist": playlist, "variant": variant}
            self.video["url"] = buildUrl(
                self.url, "stream", channel=self.channel
            )
        else:
            self.video =  None
            self.playlists = {}

    # --------------------------------------------------------------------------

    def __stream__(self, quality):
        reset = False
        if (response := self.__get__(*self.playlists["playlist"][quality])):
            state, reset = self.discontinuity.push(response)
            if state:
                notify(30006, icon=ICONWARNING, time=10000)
                response = self.__get__(
                    *self.playlists["variant"].best(quality=quality)
                )
        if response:
            return (self.__m3u8__(response.text, response), reset)

    def stream(self, quality=None):
        if quality:
            return self.__stream__(quality)
        if (response := self.__get__(*self.playlists["playlist"].best())):
            state, _ = self.discontinuity.push(response)
            if state:
                return (self.playlists["variant"], False)
        return (self.playlists["playlist"], False)
