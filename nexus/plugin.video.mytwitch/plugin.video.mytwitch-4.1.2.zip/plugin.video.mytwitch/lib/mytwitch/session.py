# -*- coding: utf-8 -*-


import ssl

from requests import Session
from requests.adapters import HTTPAdapter

from iapc import Client


# ------------------------------------------------------------------------------
# MyHTTPAdapter

class MyHTTPAdapter(HTTPAdapter):

    __ciphers__ = (
        "ECDHE-ECDSA-AES256-GCM-SHA384",
        "ECDHE-RSA-AES256-GCM-SHA384",
        "ECDHE-ECDSA-AES128-GCM-SHA256",
        "ECDHE-RSA-AES128-GCM-SHA256",
        "ECDHE-ECDSA-CHACHA20-POLY1305",
        "ECDHE-RSA-CHACHA20-POLY1305"
    )

    def init_poolmanager(self, connections, maxsize, block=False, **kwargs):
        ssl_context = ssl.create_default_context()
        ssl_context.set_ciphers(":".join(self.__ciphers__))
        ssl_context.options |= ssl.OP_NO_COMPRESSION
        kwargs["ssl_context"] = ssl_context
        super(MyHTTPAdapter, self).init_poolmanager(
            connections, maxsize, block=block, **kwargs
        )


# ------------------------------------------------------------------------------
# MySession

class MySession(Session):

    __protocols__ = ("https", "http")

    def __init__(self, logger, key, headers):
        self.logger = logger.getLogger(component=key)
        super(MySession, self).__init__()
        self.headers.clear()
        self.headers.update(headers)
        adapter = MyHTTPAdapter()
        for protocol in self.__protocols__:
            self.mount(f"{protocol}://", adapter)

    def close(self):
        super(MySession, self).close()
        self.logger.info(f"closed")

    def get(self, url, timeout=10.0):
        try:
            response = super(MySession, self).get(url, timeout=timeout)
            response.raise_for_status()
            return response
        except Exception as error:
            self.logger.error(error)


# ------------------------------------------------------------------------------
# MySessions

class MySessions(dict):

    __verbose__ = False

    __base_headers__ = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
        "DNT": "1",
        "Pragma": "no-cache",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "none",
        "Sec-Fetch-User": "?1",
        "Sec-GPC": "1",
        "Upgrade-Insecure-Requests": "1",
    }

    __base_params__ = {
        "allowed_extractors": ["twitch:stream"],
        "verbose": __verbose__,
    }

    __extractor_args__ = {
        "playlist": {
            "client_id": ["kimne78kx3ncx6brgo4mv6wki5h1ko"]
        },
        "variant": {
            "client_id": ["ue6666qo983tsx6so1t0vnawi233wa"],
            "platform": ["ios"],
            "player_type": ["autoplay"]
        }
    }

    __client_headers__ = {
        "playlist": {
            "Client-Id": __extractor_args__["playlist"]["client_id"][0],
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:153.0) Gecko/20100101 Firefox/153.0"
        },
        "variant": {
            "Client-Id": __extractor_args__["variant"]["client_id"][0],
            "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6.1 Mobile/15E148 Safari/604.1"
        }
    }

    __headers__ = {
        "playlist": dict(__base_headers__, **__client_headers__["playlist"]),
        "variant": dict(__base_headers__, **__client_headers__["variant"])
    }

    __params__ = {
        "playlist": dict(
            __base_params__,
            http_headers=__headers__["playlist"],
            extractor_args={"twitch": __extractor_args__["playlist"]}
        ),
        "variant": dict(
            __base_params__,
            http_headers=__headers__["variant"],
            extractor_args={"twitch": __extractor_args__["variant"]}
        )
    }

    __client__ = Client("service.yt-dlp")

    # --------------------------------------------------------------------------

    def __init__(self, logger):
        self.logger = logger.getLogger(component="sessions")
        super(MySessions, self).__init__(
            {
                key: MySession(self.logger, key, self.__headers__[key])
                for key in ("playlist", "variant")
            }
        )

    def close(self):
        while self:
            _, session = self.popitem()
            session.close()
        self.logger.info(f"closed")

    # --------------------------------------------------------------------------

    def __video__(self, url, key):
        return self.__client__.video(url, params=self.__params__[key])

    def __get__(self, url, key):
        return self[key].get(url)
