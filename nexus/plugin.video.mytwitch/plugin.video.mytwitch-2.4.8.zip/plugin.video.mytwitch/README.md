# plugin.video.mytwitch

MyTwitch addon for Kodi.

Requires [inputstream.ffmpegdirect](https://github.com/xbmc/inputstream.ffmpegdirect/) and
[backports.datetime_fromisoformat](https://github.com/movermeyer/backports.datetime_fromisoformat/)
