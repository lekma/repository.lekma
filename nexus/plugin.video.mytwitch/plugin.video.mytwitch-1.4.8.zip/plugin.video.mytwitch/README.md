# plugin.video.mytwitch

MyTwitch addon for Kodi.

Requires [backports.datetime_fromisoformat](https://github.com/movermeyer/backports.datetime_fromisoformat/)
