# -*- coding: utf-8 -*-


from xbmc import Player


# ------------------------------------------------------------------------------
# MyPlayer

class MyPlayer(Player):

    def __init__(self, logger, *args, **kwargs):
        super(MyPlayer, self).__init__(*args, **kwargs)
        self.logger = logger.getLogger(component="player")
        self.__enabled__ = False
        self.__changed__ = False

    # --------------------------------------------------------------------------

    def __disable__(self):
        self.__changed__ = False
        self.__enabled__ = False

    # --------------------------------------------------------------------------

    def onAVStarted(self):
        try:
            item = self.getPlayingItem()
        except Exception:
            item = None
        self.__enabled__ = bool(item and item.getProperty("twitch:channel"))

    def onAVChange(self):
        if self.__enabled__:
            if self.__changed__:
                self.__changed__ = False
            else:
                self.__changed__ = True
                self.setAudioStream(1)

    # --------------------------------------------------------------------------

    def onPlayBackStopped(self):
        self.logger.info(f"onPlayBackStopped()")
        self.__disable__()

    def onPlayBackEnded(self):
        self.logger.info(f"onPlayBackEnded()")
        self.__disable__()

    def onPlayBackError(self):
        self.logger.info(f"onPlayBackError()")
        self.__disable__()
