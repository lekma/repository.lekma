# -*- coding: utf-8 -*-


from collections import deque
from urllib.parse import urljoin

import requests

from iapc import Client
from nuttig import buildUrl, notify, ICONWARNING

from mytwitch.m3u8 import protocol, M3U8, PlaylistList


# ------------------------------------------------------------------------------
# MyDiscontinuity

class MyDiscontinuity(deque):

    __marker__ = "#EXT-X-DISCONTINUITY\n"

    def __init__(self, maxlen=5):
        super(MyDiscontinuity, self).__init__(maxlen=maxlen)
        self.__state__ = False

    def push(self, response):
        self.append(self.__marker__ in response.text)
        if (reset := (self.__state__ != (state := any(self)))):
            self.__state__ = state
        return (state, reset)


# ------------------------------------------------------------------------------
# MyPlaylist

class MyPlaylist(dict):

    def __init__(self, playlist, channel, url):
        super(MyPlaylist, self).__init__()
        self.__playlist__ = self.__variant__(playlist, channel, url)

    def __redirect__(self, playlists, channel, url):
        for p in playlists:
            if (
                (p.stream_info.resolution is not None) and
                (p.stream_info.video is not None)
            ):
                self[(quality := p.stream_info.video)] = p.uri
                p.uri = buildUrl(url, "stream", channel=channel, quality=quality)
                yield p

    def __variant__(self, playlist, channel, url):
        playlist.playlists = PlaylistList(
            [p for p in self.__redirect__(playlist.playlists, channel, url)]
        )
        return playlist

    @property
    def content_type(self):
        return self.__playlist__.content_type

    def dumps(self):
        return self.__playlist__.dumps()


# ------------------------------------------------------------------------------
# MyChannel

class MyChannel(object):

    #__client_id__ = "kimne78kx3ncx6brgo4mv6wki5h1ko"
    __client_id__ = "ue6666qo983tsx6so1t0vnawi233wa"

    __params__ = {
        "allowed_extractors": ["twitch:stream"],
        "extractor_args": {
            "twitch": {
                "client_id": [__client_id__],
                "platform": ["ios"],
                "player_type": ["autoplay"]
            }
        }
    }

    __headers__ = {
        "Client-ID": __client_id__
    }

    __twitch_url__ = "https://www.twitch.tv"

    __client__ = Client("service.yt-dlp")

    @classmethod
    def __video__(cls, channel, params=None):
        return cls.__client__.video(
            f"{cls.__twitch_url__}/{channel}", params=params
        )

    def __new__(cls, channel, url, logger):
        if (
            (video := cls.__video__(channel)) and
            (_channel_ := super(MyChannel, cls).__new__(cls)) and
            _channel_.__setup__(
                video=video,
                channel=channel,
                url=url,
                logger=logger.getLogger(component=channel),
                discontinuity=MyDiscontinuity()
            )
        ):
            return _channel_

    def __setup__(self, **kwargs):
        for key, value in kwargs.items():
            setattr(self, key, value)
        if (playlist := self.__playlist__(self.video["url"])):
            self.playlist = MyPlaylist(playlist, self.channel, self.url)
            if (
                (video := self.__video__(self.channel, params=self.__params__)) and
                (playlist := self.__playlist__(video["url"]))
            ):
                self.playlist.update(
                    MyPlaylist(playlist, self.channel, self.url)
                )
            self.video["url"] = buildUrl(self.url, "stream", channel=self.channel)
            return True
        return False

    # --------------------------------------------------------------------------

    def __get__(self, url, timeout=10.0, **kwargs):
        try:
            response = requests.get(
                url, timeout=timeout, headers=self.__headers__, **kwargs
            )
            response.raise_for_status()
            return response
        except Exception as error:
            self.logger.error(error)

    # --------------------------------------------------------------------------

    __protocol__ = (
        protocol.ext_m3u,
        protocol.ext_x_media,
        protocol.ext_x_stream_inf,
        protocol.ext_x_version,
        protocol.ext_x_targetduration,
        protocol.ext_x_media_sequence,
        protocol.ext_x_start,
        protocol.extinf,
        protocol.ext_x_endlist
    )

    def __parser__(self, line, lineno, data, state):
        if line.startswith(self.__protocol__):
            return False
        return True

    def __m3u8__(self, response):
        try:
            playlist = M3U8(
                response.text,
                base_uri=urljoin(response.url, "."),
                custom_tags_parser=self.__parser__
            )
            playlist.url = response.url
            playlist.content_type = response.headers["content-type"]
            return playlist
        except Exception as error:
            self.logger.error(error)

    def __playlist__(self, url):
        if (response := self.__get__(url)):
            return self.__m3u8__(response)

    def __stream__(self, quality):
        reset = False
        if (response := self.__get__(self.playlist[quality])):
            discontinuity, reset = self.discontinuity.push(response)
            #self.logger.info("\n\n\n")
            #self.logger.info(f"self.discontinuity: {self.discontinuity}")
            #self.logger.info(f"discontinuity: {discontinuity}")
            #self.logger.info(f"reset: {reset}")
            #self.logger.info("\n\n\n")
            if discontinuity:
                notify(30006, icon=ICONWARNING)
                response = self.__get__(self.playlist["360p30"])
        if response:
            return (self.__m3u8__(response), reset)

    # --------------------------------------------------------------------------

    def stream(self, quality=None):
        if quality:
            return self.__stream__(quality)
        return (self.playlist, False)
