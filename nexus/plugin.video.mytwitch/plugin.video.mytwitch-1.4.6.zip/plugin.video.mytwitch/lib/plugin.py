# -*- coding: utf-8 -*-


from sys import argv
from urllib.parse import urlencode

from inputstreamhelper import Helper

from nuttig import action, parseQuery, Plugin

from mytwitch.client import MyClient
from mytwitch.items import addChannelItem


# ------------------------------------------------------------------------------
# MyPlugin

class MyPlugin(Plugin):

    def __init__(self, *args, **kwargs):
        super(MyPlugin, self).__init__(*args, **kwargs)
        self.__client__ = MyClient(self.logger)

    # helpers ------------------------------------------------------------------

    def addAddChannel(self):
        return self.addItem(addChannelItem(self.url, action="addChannel"))

    # play ---------------------------------------------------------------------

    def playItem(
        self,
        item,
        manifestType,
        mimeType=None,
        language=None,
        headers=None,
        params=None
    ):
        #self.logger.info(
        #    f"playItem(item={item}, manifestType={manifestType}, "
        #    f"mimeType={mimeType}, language={language}, "
        #    f"headers={headers}, params={params})"
        #)
        if item:
            if not Helper(manifestType).check_inputstream():
                return False
            item.setProperty("inputstream", "inputstream.adaptive")
            item.setProperty("inputstream.adaptive.manifest_type", manifestType)
            if language:
                item.setProperty(
                    "inputstream.adaptive.original_audio_language", language
                )
            if headers and isinstance(headers, dict):
                item.setProperty(
                    "inputstream.adaptive.manifest_headers", urlencode(headers)
                )
            if params and isinstance(params, dict):
                item.setProperty(
                    "inputstream.adaptive.manifest_params", urlencode(params)
                )
            return super(MyPlugin, self).playItem(item, mimeType=mimeType)
        return False

    @action()
    def play(self, **kwargs):
        self.logger.info(f"play(kwargs={kwargs})")
        args, kwargs = self.__client__.play(**kwargs)
        return self.playItem(*args, **kwargs)

    # home ---------------------------------------------------------------------

    @action(category=30000)
    def home(self, **kwargs):
        if self.addAddChannel():
            return self.addDirectory(self.__client__.channels())
        return False

    # addChannel ---------------------------------------------------------------

    @action(directory=False)
    def addChannel(self, **kwargs):
        self.__client__.addChannel()
        return True


# __main__ ---------------------------------------------------------------------

def dispatch(url, handle, query, *args):
    MyPlugin(url, int(handle)).dispatch(**parseQuery(query))


if __name__ == "__main__":
    dispatch(*argv)
