# plugin.video.invidious

[Invidious](https://github.com/iv-org/invidious/) addon for Kodi.
