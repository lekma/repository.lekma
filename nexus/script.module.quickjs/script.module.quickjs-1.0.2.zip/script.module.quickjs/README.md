# script.module.quickjs

Kodi addon for the [QuickJS](https://bellard.org/quickjs/) Javascript Engine.
