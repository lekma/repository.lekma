# script.module.graphql-core

Python [graphql-core](https://github.com/graphql-python/graphql-core/) library packaged for Kodi.
