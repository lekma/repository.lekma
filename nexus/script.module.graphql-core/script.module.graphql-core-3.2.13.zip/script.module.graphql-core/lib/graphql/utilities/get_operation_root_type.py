"""Get the root type for an operation"""

from typing import Union

from ..error import GraphQLError
from ..language import (
    OperationType,
    OperationDefinitionNode,
    OperationTypeDefinitionNode,
)
from ..type import GraphQLObjectType, GraphQLSchema

__all__ = ["get_operation_root_type"]


def get_operation_root_type(
    schema: GraphQLSchema,
    operation: Union[OperationDefinitionNode, OperationTypeDefinitionNode],
) -> GraphQLObjectType:
    """Extract the root type of the operation from the schema.

    This deprecated helper is retained for backwards compatibility; call
    :meth:`GraphQLSchema.get_root_type <graphql.type.GraphQLSchema.get_root_type>`
    instead because ``get_operation_root_type`` will be removed in v3.3.

    .. deprecated:: 3.2
       Please use ``GraphQLSchema.get_root_type`` instead. Will be removed in v3.3.

    :param schema: The GraphQL schema to use.
    :param operation: The operation definition to inspect.
    :returns: The root type of the operation.

    >>> from graphql import build_schema, get_operation_root_type, parse
    >>> schema = build_schema('type Query { name: String }')
    >>> operation = parse('{ name }').definitions[0]
    >>> root_type = get_operation_root_type(schema, operation)
    >>> root_type.name
    'Query'
    """
    operation_type = operation.operation
    if operation_type == OperationType.QUERY:
        query_type = schema.query_type
        if not query_type:
            raise GraphQLError(
                "Schema does not define the required query root type.", operation
            )
        return query_type

    if operation_type == OperationType.MUTATION:
        mutation_type = schema.mutation_type
        if not mutation_type:
            raise GraphQLError("Schema is not configured for mutations.", operation)
        return mutation_type

    if operation_type == OperationType.SUBSCRIPTION:
        subscription_type = schema.subscription_type
        if not subscription_type:
            raise GraphQLError("Schema is not configured for subscriptions.", operation)
        return subscription_type

    raise GraphQLError(
        "Can only have query, mutation and subscription operations.", operation
    )
