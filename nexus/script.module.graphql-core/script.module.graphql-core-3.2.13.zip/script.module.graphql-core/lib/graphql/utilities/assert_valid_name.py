"""Assert that a name is a valid GraphQL name"""

from typing import Optional

from ..type.assert_name import assert_name
from ..error import GraphQLError

__all__ = ["assert_valid_name", "is_valid_name_error"]


def assert_valid_name(name: str) -> str:
    """Uphold the spec rules about naming.

    This deprecated helper is retained for backwards compatibility; call ``assert_name``
    instead because ``assert_valid_name`` will be removed in v3.3.

    .. deprecated:: 3.2
       Please use ``assert_name`` instead. Will be removed in v3.3.

    :param name: The GraphQL name to validate.
    :returns: The validated GraphQL name.

    >>> from graphql import assert_valid_name
    >>> assert_valid_name('User')
    'User'
    >>> assert_valid_name('__typename')
    Traceback (most recent call last):
    ...
    graphql.error.graphql_error.GraphQLError: Name '__typename' must not begin ...
    """
    error = is_valid_name_error(name)
    if error:
        raise error
    return name


def is_valid_name_error(name: str) -> Optional[GraphQLError]:
    """Return an Error if a name is invalid.

    This deprecated helper is retained for backwards compatibility; call ``assert_name``
    and catch the raised GraphQLError instead because ``is_valid_name_error`` will be
    removed in v3.3.

    .. deprecated:: 3.2
       Please use ``assert_name`` instead. Will be removed in v3.3.

    :param name: The GraphQL name to validate.
    :returns: A GraphQLError if the name is invalid; otherwise ``None``.

    >>> from graphql import is_valid_name_error
    >>> print(is_valid_name_error('User'))
    None
    >>> error = is_valid_name_error('__typename')
    >>> print(error.message)
    Name '__typename' must not begin with '__',
    which is reserved by GraphQL introspection.
    """
    if not isinstance(name, str):
        raise TypeError("Expected name to be a string.")
    if name.startswith("__"):
        return GraphQLError(
            f"Name {name!r} must not begin with '__',"
            " which is reserved by GraphQL introspection."
        )
    try:
        assert_name(name)
    except GraphQLError as error:
        return error
    return None
