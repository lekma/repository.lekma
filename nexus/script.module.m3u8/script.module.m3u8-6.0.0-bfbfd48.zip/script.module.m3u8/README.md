# script.module.m3u8

Python [m3u8](https://github.com/globocom/m3u8/) library packaged for Kodi.

Requires [backports.datetime_fromisoformat](https://github.com/movermeyer/backports.datetime_fromisoformat/).
