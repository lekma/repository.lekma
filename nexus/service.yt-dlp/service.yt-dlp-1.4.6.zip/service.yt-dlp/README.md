# service.yt-dlp

Kodi service for [script.module.yt-dlp](https://github.com/lekma/script.module.yt-dlp).
