# service.yt-dlp

kodi service for [script.module.yt-dlp](https://github.com/lekma/script.module.yt-dlp).
