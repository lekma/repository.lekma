# script.module.packaging

Python [packaging](https://github.com/pypa/packaging/) library packaged for Kodi.
